"""
Fix PPT Slide 10 + Slide 17:
- Slide 10: "omega ~ 3.2" (blue on blue) and "omega ~ 8.1" (red on red) invisible → white text
- Slide 17: Redesign migration visualization for clarity
Covers both EN and ZH versions.
"""

from pptx import Presentation
from pptx.util import Inches, Emu, Pt, Cm
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn
from lxml import etree
from PIL import Image, ImageDraw, ImageFont
import os, io, copy

BASE = r"C:\Users\KnightZ\Desktop\细胞受选择\results\figures_final"


def fix_slide10(prs, lang="EN"):
    """Slide 10: Change omega value text on bars to white for visibility."""
    slide = prs.slides[9]
    
    # Shape 30: "omega ~ 3.2" on blue bar (2563EB) → white
    # Shape 31: "omega ~ 8.1" on red bar (DC2626) → white
    for idx in [30, 31]:
        shape = slide.shapes[idx]
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                    run.font.bold = True
                    run.font.size = Pt(8)
    
    print(f"  [{lang}] Slide 10: omega values → white (was invisible on colored bars)")


def generate_migration_diagram(lang="EN"):
    """Generate a clear migration diagram: omega gradient bar with zones."""
    W, H = 1600, 500
    img = Image.new('RGBA', (W, H), (248, 250, 252, 255))  # #F8FAFC
    draw = ImageDraw.Draw(img)
    
    # Try to load font
    try:
        font_title = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 22)
        font_body = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 14)
        font_small = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 11)
    except:
        font_title = ImageFont.load_default()
        font_body = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # --- Gradient bar ---
    bar_x, bar_y = 80, 180
    bar_w, bar_h = 1440, 40
    
    # 5-segment gradient from green (low omega) to red (high omega)
    segments = [
        (0, (13, 148, 136)),     # #0D9488 teal
        (1, (59, 130, 246)),     # #3B82F6 blue
        (2, (139, 92, 246)),     # #8B5CF6 purple
        (3, (245, 158, 11)),     # #F59E0B amber
        (4, (220, 38, 38)),      # #DC2626 red
    ]
    
    seg_w = bar_w // 5
    for i, (_, color) in enumerate(segments):
        x0 = bar_x + i * seg_w
        r = 6 if i == 0 or i == 4 else 0
        draw.rounded_rectangle(
            [x0, bar_y, x0 + seg_w, bar_y + bar_h],
            radius=r, fill=color
        )
    
    # --- Zone labels ---
    zones_en = ["SVZ\n(origin)", "Corpus\nCallosum", "Cortical\nWhite Matter", "Cortex\nLayer I-VI", "omega: low → high"]
    zones_zh = ["SVZ\n(起源)", "胼胝体", "皮层白质", "皮层\nI-VI层", "ω: 低 → 高"]
    zones = zones_en if lang == "EN" else zones_zh
    
    zone_positions = [80, 380, 650, 900, 1200]
    for i, (zx, ztext) in enumerate(zip(zone_positions, zones)):
        lines = ztext.split('\n')
        if i < 4:
            # Draw vertical tick mark
            tick_x = zx + seg_w // 2
            draw.line([(tick_x, bar_y + bar_h), (tick_x, bar_y + bar_h + 12)], 
                      fill=(30, 41, 59), width=2)
        for li, line in enumerate(lines):
            draw.text((zx + seg_w//2 - 40, bar_y + bar_h + 18 + li * 18), 
                      line, fill=(30, 41, 59), font=font_small, anchor='mt')
    
    # --- Migration arrow ---
    arrow_y = bar_y - 55
    arrow_color = (220, 38, 38)  # red
    
    # Arrow line
    draw.line([(bar_x + 20, arrow_y), (bar_x + bar_w - 20, arrow_y)], 
              fill=arrow_color, width=4)
    # Arrow head
    draw.polygon([
        (bar_x + bar_w - 10, arrow_y - 10),
        (bar_x + bar_w + 5, arrow_y),
        (bar_x + bar_w - 10, arrow_y + 10),
    ], fill=arrow_color)
    
    arrow_text = "OPC Migration Path" if lang == "EN" else "OPC 迁移路径"
    draw.text((bar_x + bar_w // 2, arrow_y - 18), arrow_text, 
              fill=(220, 38, 38), font=font_small, anchor='mb')
    
    # --- OPC start marker ---
    start_x = bar_x + seg_w // 2
    ocy = 60
    draw.ellipse([start_x - 8, ocy - 8, start_x + 8, ocy + 8], 
                 fill=(37, 99, 235), outline=(30, 41, 59), width=2)
    opc_text = "OPC" if lang == "EN" else "OPC"
    draw.text((start_x, ocy - 16), opc_text, 
              fill=(37, 99, 235), font=font_body, anchor='mb')
    
    # --- End marker ---
    end_x = bar_x + bar_w - seg_w // 2
    draw.ellipse([end_x - 8, ocy - 8, end_x + 8, ocy + 8],
                 fill=(220, 38, 38), outline=(30, 41, 59), width=2)
    end_text = "Cortex" if lang == "EN" else "皮层"
    draw.text((end_x, ocy - 16), end_text,
              fill=(220, 38, 38), font=font_body, anchor='mb')
    
    # --- Omega labels at key points ---
    omega_annotations = [
        (bar_x + seg_w // 2, "~3", (13, 148, 136)),
        (bar_x + bar_w - seg_w // 2, "~22", (220, 38, 38)),
    ]
    for ox, otext, ocolor in omega_annotations:
        draw.text((ox, bar_y - 10), f"omega={otext}", 
                  fill=ocolor, font=font_small, anchor='ms')
    
    os.makedirs(os.path.join(BASE, "slide17_temp"), exist_ok=True)
    out_path = os.path.join(BASE, "slide17_temp", f"migration_diagram_{lang.lower()}.png")
    img.save(out_path)
    print(f"  Generated: {out_path}")
    return out_path


def fix_slide17(prs, lang="EN"):
    """Slide 17: Replace complex brain image with clear migration diagram."""
    slide = prs.slides[16]
    
    # --- Step 1: Remove old migration overlay shapes ---
    to_remove = []
    shapes_to_check = list(slide.shapes)
    for i, shape in enumerate(shapes_to_check):
        if shape.name and ("Connector" in shape.name or "TextBox" in shape.name):
            to_remove.append(shape._element)
    
    spTree = slide.shapes._spTree
    for elem in to_remove:
        spTree.remove(elem)
    print(f"  [{lang}] Slide 17: Removed {len(to_remove)} migration overlay shapes")
    
    # --- Step 2: Find and replace the brain image ---
    brain_shape_idx = None
    for i, shape in enumerate(slide.shapes):
        if shape.shape_type == 13:  # PICTURE
            brain_shape_idx = i
            break
    
    # --- Step 3: Generate new migration diagram ---
    diagram_path = generate_migration_diagram(lang)
    
    # --- Step 4: Replace brain image with migration diagram ---
    if brain_shape_idx is not None:
        brain_shape = slide.shapes[brain_shape_idx]
        # Save position/size
        left = brain_shape.left
        top = brain_shape.top
        width = brain_shape.width
        height = brain_shape.height * 2 // 3  # Smaller, make room for explanations below
        
        # Delete old image
        spTree.remove(brain_shape._element)
        
        # Add new diagram
        new_pic = slide.shapes.add_picture(diagram_path, left, top, width, height)
        print(f"  [{lang}] Slide 17: Replaced brain image with migration diagram")
    
    # --- Step 5: Update text cards ---
    # Left card: "Regional Identity Landscape" → "Omega Gradient"
    # Right card: "Cell Migration Inference" → "Migration Hypothesis"
    
    for shape in slide.shapes:
        if not shape.has_text_frame:
            continue
        full_text = shape.text_frame.text
        
        if "Regional Identity Landscape" in full_text or "区域身份景观" in full_text:
            # Update title
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if "Regional Identity Landscape" in run.text:
                        run.text = "Omega Gradient Across Brain Regions"
                    elif "区域身份景观" in run.text:
                        run.text = "脑区 Omega 梯度"
        
        if "Cell Migration Inference" in full_text or "细胞迁移推断" in full_text:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if "Cell Migration Inference" in run.text:
                        run.text = "OPC Migration Hypothesis"
                    elif "细胞迁移推断" in run.text:
                        run.text = "OPC 迁移假说"
        
        # Simplify body text: remove verbose explanation
        # Replace with concise 2-line description
        if "Cortical regions show highest" in full_text:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    run.text = run.text.replace(
                        "Cortical regions show highest omega for astrocytes (107.5). Cerebellar Bergmann glia form distinct cluster. Subcortical regions (thalamus, striatum) show moderate omega values.",
                        "Astrocytes show omega = 107.5 in cortical regions. Bergmann glia (cerebellum) form a distinct cluster. Thalamus and striatum show moderate omega."
                    )
        
        if "This spatial omega landscape provides a quantitative framework" in full_text:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    run.text = run.text.replace(
                        "This spatial omega landscape provides a quantitative framework for understanding brain cell identity.",
                        "omega landscape quantifies regional cell identity — providing a gradient-based view of brain cell specialization."
                    )
        
        if "Oligodendrocyte precursor cells" in full_text:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    for old, new in [
                        ("Oligodendrocyte precursor cells (OPC) migrate from subventricular zone (SVZ) to cortex. CKI detects the migration path via omega gradient: omega increases from SVZ (~3) to cortex (~22).", 
                         "OPCs migrate from SVZ (omega ~3) → cortex (omega ~22). CKI tracks this via the omega gradient — higher omega = stronger differentiation signal downstream."),
                        ("Generates testable cell migration hypotheses, adding mechanistic insight to descriptive cell atlases.",
                         "This gradient generates testable migration hypotheses, linking spatial location to functional differentiation strength.")
                    ]:
                        if old in run.text:
                            run.text = run.text.replace(old, new)
    
    # ZH version text fixes
    if lang == "ZH":
        for shape in slide.shapes:
            if not shape.has_text_frame:
                continue
            full_text = shape.text_frame.text
            if "皮层区域的星形胶质细胞" in full_text:
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if "皮层区域的星形胶质细胞" in run.text:
                            run.text = run.text.replace(
                                "皮层区域的星形胶质细胞 omega 最高 (107.5)。小脑 Bergmann 胶质细胞形成独立聚类。皮层下区域（丘脑、纹状体）呈现中等 omega 值。",
                                "星形胶质细胞：皮层 omega = 107.5。Bergmann胶质（小脑）独立成簇。丘脑/纹状体 omega 中等。"
                            )
                        if "该空间 omega 图谱为理解脑细胞身份提供了定量框架" in run.text:
                            run.text = run.text.replace(
                                "该空间 omega 图谱为理解脑细胞身份提供了定量框架。",
                                "omega 梯度量化了脑区细胞身份——为脑细胞特化提供了基于梯度的视角。"
                            )
            if "少突胶质前体细胞" in full_text or "OPC" in full_text:
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if "少突胶质前体细胞 (OPC) 从脑室下区 (SVZ) 迁移到皮层" in run.text:
                            run.text = run.text.replace(
                                "少突胶质前体细胞 (OPC) 从脑室下区 (SVZ) 迁移到皮层。CKI 检测到迁移路径的 omega 梯度：omega 从 SVZ (~3) 增加到皮层 (~22)。",
                                "OPC 从 SVZ (omega ~3) 迁移至皮层 (omega ~22)。CKI 通过 omega 梯度追踪这一路径——omega 越高 = 下游分化信号越强。"
                            )
                        if "生成可验证的细胞迁移假说" in run.text:
                            run.text = run.text.replace(
                                "生成可验证的细胞迁移假说，为描述性细胞图谱添加机制性洞察。",
                                "该梯度生成可验证的迁移假说，将空间位置与功能分化强度联系起来。"
                            )
    
    print(f"  [{lang}] Slide 17: Updated card text for clarity")


# ===========================
# Main
# ===========================
for lang_label, ppt_path in [
    ("EN", os.path.join(BASE, "CKI_Lecture_2026_v3.pptx")),
    ("ZH", os.path.join(BASE, "CKI_Lecture_2026_v3_ZH.pptx")),
]:
    print(f"\n{'='*50}")
    print(f"Processing {lang_label} PPT")
    print(f"{'='*50}")
    
    prs = Presentation(ppt_path)
    
    fix_slide10(prs, lang_label)
    fix_slide17(prs, lang_label)
    
    prs.save(ppt_path)
    print(f"  [{lang_label}] Saved")

print("\nDone!")
