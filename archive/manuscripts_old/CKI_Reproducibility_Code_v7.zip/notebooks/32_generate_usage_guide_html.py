"""
CKI Usage Guide — HTML Generator (v7)
=========================================
Generates two HTML files (EN + ZH) with:
  - Clean CSS design system (navy/gold palette)
  - SVG brain outline: compact layout, labels near circles (original style)
  - NO Chinese text in EN version (verified)
  - Arrows: thin 1.5px

Output: results/figures_final/usage_guide_en.html
        results/figures_final/usage_guide_zh.html
"""
import sys, re
from pathlib import Path

OUT_DIR = Path(r"C:\Users\KnightZ\Desktop\细胞受选择\results\figures_final")
OUT_DIR.mkdir(exist_ok=True)

# ===========================================================
# Color Palette (CSS :root variables)
# ===========================================================
ROOT_CSS = """
:root {
    --navy:       #1a2d5c;
    --navy-light: #2a4a8a;
    --gold:       #c8a951;
    --gold-light: #e8dcc8;
    --gold-pale:  #faf7f0;
    --mist:       #4a7eb5;
    --converge:   #2d7a4f;
    --diverge:    #c0392b;
    --neutral:    #6b7280;
    --white:      #ffffff;
    --bg-card:    #fafafa;
    --rule:       #e8dcc8;
    --shadow-sm:  0 1px 3px rgba(26,45,92,0.08);
    --shadow-md:  0 4px 16px rgba(26,45,92,0.10);
    --radius:     8px;
}
"""

# ===========================================================
# Data: English Version
# ===========================================================
EN = {
    "lang": "en",
    "title": "CKI User Guide",
    "subtitle": "Cell-state Kinetic Index — From Data to Biological Insight",
    "subtitle_en": "A visual reference for practitioners",
    "version": "v1.0",
    "sections": {
        "pipeline": {
            "num": "1",
            "title": "Core Pipeline",
            "desc": "Input → Classification → Divergence → Output",
            "steps": [
                {"id": "01", "title": "Input Data",      "sub": "Input",
                 "items": ["Gene expression matrix (cells x genes) — any species",
                           "HK genes auto-detected (detection + CV filter)",
                           "Identity genes auto-detected (HVGs, excl. HK)"]},
                {"id": "02", "title": "Classify Genes",   "sub": "Classify",
                 "items": ["Housekeeping (HK), neutral reference",
                           "Identity genes, functional markers",
                           "Per-gene JS divergence (calibrated)"]},
                {"id": "03", "title": "Compute Divergence", "sub": "Compute",
                 "items": ["HK -> k_n (neutral divergence)",
                           "Identity -> k_f (functional)",
                           "Bootstrap CI (uncertainty estimate)"]},
                {"id": "04", "title": "Output ω",       "sub": "Output",
                 "items": ["ω = k_f / k_n",
                           "Statistical significance (P value, FDR)",
                           "Biological interpretation (selection pressure)"]},
            ],
        },
        "interpret": {
            "num": "2",
            "title": "Interpret ω",
            "desc": "ω = k_f / k_n — Interpretation Guide",
            "bands": [
                {"label": "ω < 0.5",  "desc": "Convergent / Purifying selection — Transcriptome homogenization", "color": "converge"},
                {"label": "ω ≈ 0.5–1.5", "desc": "Neutral range — No directional selection",                     "color": "neutral"},
                {"label": "ω > 1.5",  "desc": "Divergent / Positive selection — Transcriptome remodeling",   "color": "diverge"},
            ],
            "formula": "ω = k_f / k_n",
            "explanations": [
                ("k_f",  "Jensen-Shannon divergence of identity genes"),
                ("k_n", "Jensen-Shannon divergence of HK genes (neutral ref.)"),
                ("ω < 1", "Transcriptome convergence (purifying)"),
                ("ω > 1", "Transcriptome divergence (positive selection)"),
            ],
        },
        "casestudy": {
            "num": "3",
            "title": "Case Study: Human Brain Cell Migration",
            "desc": "Siletti et al. 888K nuclei, ~100 regions  |  OPC migration analysis",
            "table_header": ["Cell Type", "ω", "P value", "Evidence"],
            "table_rows": [
                ("OPC",      "1.19", "3.2×10⁻⁴", "Vascular-guided migration", "diverge"),
                ("Astrocyte", "0.87", "0.012",    "Regional specification",      "neutral"),
                ("Microglia", "0.72", "0.045",    "Immune homing",            "converge"),
            ],
            "highlight": "★ Strongest signal: OPC (ω=1.19)",
            "note": "Frontal → Temporal migration\nConsistent with vascular-guided OPC migration\n(Tsai 2016, Akay 2022)",
            "count": "213/31,740 significant migration candidates (0.67%)",
        },
        "quickstart": {
            "title": "Quick Start",
            "lines": ["$ pip install git+https://github.com/zhanglknt/CKI-cell-type-identification.git",
                       ">>> from cki import compute",
                       ">>> result = compute(adata, species='human',",
                       ">>>     groupby='cell_type', group_a='T', group_b='B')"],
            "extra_lines": ["# Hybrid mode — per-pair DE genes",
                            ">>> result = compute(adata, species='human',",
                            ">>>     func_method='pairwise_de', n_top_genes=200,",
                            ">>>     groupby='cell_type', group_a='T', group_b='B')"],
        },
    },
    "footer_left":  "github.com/zhanglknt/CKI-cell-type-identification",
    "footer_right": "pip install git+github.com/zhanglknt/CKI-cell-type-identification  |  MIT License",
}

# ===========================================================
# Data: Chinese Version
# ===========================================================
ZH = {
    "lang": "zh",
    "title": "CKI 使用指南",
    "subtitle": "细胞状态动力学指数 — 从数据到生物学洞察",
    "subtitle_en": "A visual reference for practitioners",
    "version": "v1.0",
    "sections": {
        "pipeline": {
            "num": "1",
            "title": "核心流程",
            "desc": "输入 → 分类 → 分化 → 输出",
            "steps": [
                {"id": "01", "title": "输入数据",       "sub": "Input",
                 "items": ["基因表达矩阵",
                           "管家基因自动检测（检出率+CV过滤）",
                           "身份基因自动检测（HVG，排除HK）"]},
                {"id": "02", "title": "基因分类",       "sub": "Classify",
                 "items": ["管家基因 HK（中性参考）",
                           "身份基因（功能标记）",
                           "逐基因 JS 散度（校准）"]},
                {"id": "03", "title": "计算分化",       "sub": "Compute",
                 "items": ["HK → k_n（中性分化）",
                           "Identity → k_f（功能分化）",
                           "Bootstrap CI（不确定性估计）"]},
                {"id": "04", "title": "输出 ω",        "sub": "Output",
                 "items": ["ω = k_f / k_n",
                           "统计显著性（P值、FDR）",
                           "生物学解释（选择压力）"]},
            ],
        },
        "interpret": {
            "num": "2",
            "title": "解读 ω",
            "desc": "ω = k_f / k_n — 解读指南",
            "bands": [
                {"label": "ω < 0.5",  "desc": "收敛 / 净化选择 — 转录组均质化", "color": "converge"},
                {"label": "ω ≈ 0.5–1.5", "desc": "中性范围 — 无方向性选择",     "color": "neutral"},
                {"label": "ω > 1.5",  "desc": "分化 / 正向选择 — 转录组重塑", "color": "diverge"},
            ],
            "formula": "ω = k_f / k_n",
            "explanations": [
                ("k_f",  "身份基因的 Jensen-Shannon 散度"),
                ("k_n", "管家基因的 Jensen-Shannon 散度（中性参考）"),
                ("ω < 1", "转录组收敛（净化选择）"),
                ("ω > 1", "转录组分化（正向选择）"),
            ],
        },
        "casestudy": {
            "num": "3",
            "title": "案例分析：人脑细胞迁移",
            "desc": "Siletti et al. 888K 核，~100 区域  |  OPC 迁移分析",
            "table_header": ["细胞类型", "ω", "P 值", "证据"],
            "table_rows": [
                ("OPC",      "1.19", "3.2×10⁻⁴", "血管引导迁移", "diverge"),
                ("Astrocyte", "0.87", "0.012",    "区域特化",   "neutral"),
                ("Microglia", "0.72", "0.045",    "免疫归巢",   "converge"),
            ],
            "highlight": "★ 最强信号：OPC (ω=1.19)",
            "note": "额叶 → 颞叶迁移\n与血管引导 OPC 迁移一致\n(Tsai 2016, Akay 2022)",
            "count": "213/31,740 显著迁移候选（0.67%）",
        },
        "quickstart": {
            "title": "快速开始",
            "lines": ["$ pip install git+https://github.com/zhanglknt/CKI-cell-type-identification.git",
                       ">>> from cki import compute",
                       ">>> result = compute(adata, species='human',",
                       ">>>     groupby='cell_type', group_a='T', group_b='B')"],
            "extra_lines": ["# Hybrid 模式 — 逐对差异基因",
                            ">>> result = compute(adata, species='human',",
                            ">>>     func_method='pairwise_de', n_top_genes=200,",
                            ">>>     groupby='cell_type', group_a='T', group_b='B')"],
        },
    },
    "footer_left":  "github.com/zhanglknt/CKI-cell-type-identification",
    "footer_right": "pip install git+github.com/zhanglknt/CKI-cell-type-identification  |   MIT 许可证",
}

# ===========================================================
# SVG Brain Outline + Region Circles + Arrows
# Original compact layout: labels placed near circles, no crowding
# ===========================================================

# Region data: (name_en, name_zh, cx, cy, color_key)
# Coordinates in SVG viewBox "0 0 100 60" (compact, ~60% height)
BRAIN_REGIONS = [
    ("Frontal Cortex",  "额叶皮层",    18, 20, "converge"),
    ("Parietal Cortex", "顶叶皮层",    82, 20, "converge"),
    ("Temporal Cortex", "颞叶皮层",    18, 52, "converge"),
    ("Occipital Cortex", "枕叶皮层",    82, 52, "converge"),
    ("Hippocampus",     "海马体",       50, 22, "mist"),
    ("Thalamus",         "丘脑",          50, 40, "mist"),
    ("Striatum",        "纹状体",        50, 58, "gold"),
    ("Cerebellum",       "小脑",          50,  8, "diverge"),
]

# Migration arrows: (x1, y1, x2, y2)  curved
BRAIN_ARROWS = [
    (50, 58, 18, 52),   # Striatum  → Temporal
    (50, 22, 18, 52),   # Hippocampus → Temporal
    (50, 40, 50, 22),   # Thalamus → Hippocampus
    (82, 20, 18, 20),   # Parietal → Frontal
]

COLOR_HEX = {
    "converge": "#2d7a4f",
    "mist":     "#4a7eb5",
    "gold":     "#c8a951",
    "diverge": "#c0392b",
    "neutral":  "#6b7280",
}

# Label placement: for each region, specify where the label text goes
# relative to the circle: "top", "bottom", "left", "right", "top-left", etc.
# This gives full manual control over label positions to avoid overlap.
# Labels are placed NEAR circles (not all on one side), natural layout.
LABEL_PLACEMENT = {
    # en_name -> (anchor, x_offset, y_offset, dy_lines)
    # anchor: "middle" (above/below), "start" (right of circle), "end" (left of circle)
    # x_offset: added to cx to get text x
    # y_offset: added to cy to get text y (baseline)
    # dy_lines: list of dy values for multi-line labels
    # viewBox = "0 0 100 75", all ty = cy+y_offset must be within ~2..73
    "Frontal Cortex":  ("middle",  0, -10, [0, 3.8]),   # above (ty=10)
    "Parietal Cortex": ("middle",  0, -10, [0, 3.8]),   # above (ty=10)
    "Temporal Cortex": ("middle",  0,  10, [0, 3.8]),   # below (ty=62) -> need fix
    "Occipital Cortex":("middle",  0,  10, [0, 3.8]),   # below (ty=62)
    "Hippocampus":     ("end",    -9,   0,  [0]),         # left of circle (tx=41,ty=22)
    "Thalamus":         ("start",   9,   0,  [0]),         # right of circle (tx=59,ty=40)
    "Striatum":        ("middle",  0,   2,  [0]),         # below circle (ty=60)
    "Cerebellum":      ("middle",  0,  -6,  [0]),         # above circle (ty=2)
}


def make_brain_svg(lang):
    """
    Brain region diagram — compact layout.
    Labels placed NEAR circles (original natural layout), NOT all on one side.
    Labels are part of the figure, placed around circles to avoid crowding.
    viewBox is compact (height=60): smaller diagram area.
    Arrows: thin 1.5px.
    lang: "en" or "zh" — selects label language.
    """
    svg = f'''<svg viewBox="0 0 100 75" xmlns="http://www.w3.org/2000/svg"
     style="width:100%;height:100%;background:var(--bg-card);border-radius:var(--radius);">
<defs>
  <marker id="arrowhead" markerWidth="6" markerHeight="5" refX="5" refY="2.5" orient="auto-start-reverse">
    <polygon points="0 0, 6 2.5, 0 5" fill="#c0392b"/>
  </marker>
</defs>

<!-- Brain outline: left hemisphere -->
<ellipse cx="30" cy="32" rx="26" ry="26" fill="none" stroke="#1a2d5c" stroke-width="1.5" opacity="0.25"/>
<!-- Brain outline: right hemisphere -->
<ellipse cx="70" cy="32" rx="26" ry="26" fill="none" stroke="#1a2d5c" stroke-width="1.5" opacity="0.25"/>
<!-- Inter-hemispheric fissure -->
<line x1="50" y1="4" x2="50" y2="58" stroke="#1a2d5c" stroke-width="0.6" opacity="0.15"/>
'''

    # ---- 1. Draw arrows (behind circles), thin 1.5px ----
    for (x1, y1, x2, y2) in BRAIN_ARROWS:
        # Quadratic Bezier curve for smooth arrow
        mx = (x1 + x2) * 0.5 + 3
        my = (y1 + y2) * 0.5 - 5
        svg += f'<path d="M{x1},{y1} Q{mx},{my} {x2},{y2}" ' \
               f'stroke="#c0392b" stroke-width="1.5" fill="none" ' \
               f'marker-end="url(#arrowhead)" opacity="0.75"/>\n'

    # ---- 2. Draw circles (brain regions) — original size r="6" ----
    for (name_en, name_zh, cx, cy, color_key) in BRAIN_REGIONS:
        color = COLOR_HEX.get(color_key, "#888")
        svg += f'<circle cx="{cx}" cy="{cy}" r="6" fill="{color}" fill-opacity="0.5" ' \
               f'stroke="#fff" stroke-width="1.8"/>\n'

    # ---- 3. Labels NEAR circles (natural layout, NOT all on one side) ----
    for (name_en, name_zh, cx, cy, color_key) in BRAIN_REGIONS:
        color = COLOR_HEX.get(color_key, "#888")
        label = name_zh if lang == "zh" else name_en
        placement = LABEL_PLACEMENT.get(name_en)
        if placement is None:
            # Default: above the circle
            anchor = "middle"
            tx = cx
            ty = cy - 12
            dys = [0, 4.2]
        else:
            (anchor, x_off, y_off, dys) = placement
            tx = cx + x_off
            ty = cy + y_off

        # Split label into lines (by space, ~10 chars per line)
        words = label.split()
        if len(words) <= 2:
            lines = [" ".join(words)]
        else:
            # Split into two roughly equal parts
            mid = len(words) // 2
            lines = [" ".join(words[:mid]), " ".join(words[mid:])]

        svg += f'<text x="{tx}" y="{ty}" text-anchor="{anchor}" ' \
               f'font-family="Arial" font-size="3.0" fill="#1a2d5c" font-weight="700" ' \
               f'style="pointer-events:none;">\n'
        dy_acc = 0
        for i, ln in enumerate(lines):
            if i == 0:
                svg += f'  <tspan x="{tx}" dy="{dys[0]}">{ln}</tspan>\n'
            else:
                dy = dys[1] if len(dys) > 1 else 4.2
                svg += f'  <tspan x="{tx}" dy="{dy}">{ln}</tspan>\n'
        svg += f'</text>\n'

    svg += '</svg>'
    return svg


# ===========================================================
# HTML Builder
# ===========================================================
def build_html(d):
    """Build full HTML string from data dict d."""
    sections = d["sections"]
    pipeline   = sections["pipeline"]
    interpret  = sections["interpret"]
    casestudy  = sections["casestudy"]
    quickstart = sections["quickstart"]

    # ---- Brain SVG ----
    brain_svg_html = make_brain_svg(d["lang"])

    # ---- Pipeline Steps HTML ----
    pipeline_html = ""
    for step in pipeline["steps"]:
        items_html = "\n".join(f'<li style="margin:4px 0;">{it}</li>' for it in step["items"])
        pipeline_html += f'''
        <div style="flex:1;min-width:200px;background:var(--bg-card);border-radius:var(--radius);
                    padding:20px;border:1px solid var(--rule);box-shadow:var(--shadow-sm);">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            <span style="display:inline-flex;align-items:center;justify-content:center;
                         width:32px;height:32px;border-radius:50%;
                         background:var(--navy);color:#fff;font-weight:700;font-size:14px;">{step["id"]}</span>
            <div>
              <div style="font-weight:700;color:var(--navy);font-size:15px;">{step["title"]}</div>
              <div style="font-size:11px;color:var(--neutral);">{step["sub"]}</div>
            </div>
          </div>
          <ul style="margin:0;padding-left:18px;font-size:13px;color:#374151;line-height:1.7;">{items_html}</ul>
        </div>'''

    # ---- Interpret bands HTML ----
    bands_html = ""
    for band in interpret["bands"]:
        color = COLOR_HEX.get(band["color"], "#888")
        bands_html += f'''
        <div style="flex:1;min-width:160px;padding:14px 16px;
                    border-left:4px solid {color};background:var(--bg-card);
                    border-radius:0 var(--radius) var(--radius) 0;box-shadow:var(--shadow-sm);">
          <div style="font-weight:800;font-size:15px;color:{color};">{band["label"]}</div>
          <div style="font-size:12.5px;color:#374151;margin-top:4px;">{band["desc"]}</div>
        </div>'''

    explanations_html = ""
    for (sym, desc) in interpret["explanations"]:
        explanations_html += f'<div style="margin:6px 0;"><span style="font-family:monospace;font-weight:700;color:var(--navy);">{sym}</span> = {desc}</div>'

    # ---- Case Study table HTML ----
    table_rows_html = ""
    for (ctype, omega, pval, evidence, row_color) in casestudy["table_rows"]:
        c = COLOR_HEX.get(row_color, "#888")
        table_rows_html += f'''<tr>
          <td style="padding:8px 12px;font-weight:600;color:{c};">{ctype}</td>
          <td style="padding:8px 12px;font-family:monospace;font-weight:700;">{omega}</td>
          <td style="padding:8px 12px;font-size:12px;">{pval}</td>
          <td style="padding:8px 12px;font-size:12.5px;">{evidence}</td>
        </tr>'''

    # ---- Quick start code block ----
    code_html = "\n".join(f'<div style="font-family:monospace;font-size:13px;margin:2px 0;">{ln}</div>' for ln in quickstart["lines"])
    extra_code = ""
    if "extra_lines" in quickstart and quickstart["extra_lines"]:
        extra_code = "\n".join(f'<div style="font-family:monospace;font-size:13px;margin:2px 0;">{ln}</div>' for ln in quickstart["extra_lines"])
        extra_code = f'<div style="margin-top:8px;border-top:1px solid var(--rule);padding-top:8px;">{extra_code}</div>'

    full_html = f'''<!DOCTYPE html>
<html lang="{d["lang"]}">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>{d["title"]} | CKI</title>
<style>
{ROOT_CSS}
* {{margin:0;padding:0;box-sizing:border-box;}}
body {{font-family:"Segoe UI",Arial,sans-serif;background:var(--gold-pale);color:#1f2937;line-height:1.6;}}
.container {{max-width:640px;margin:0 auto;padding:24px 20px;}}
.header {{text-align:center;padding:32px 20px;background:linear-gradient(135deg,var(--navy) 0%,var(--navy-light) 100%);
           color:#fff;border-radius:var(--radius);box-shadow:var(--shadow-md);margin-bottom:24px;}}
.header h1 {{font-size:24px;font-weight:800;margin-bottom:6px;letter-spacing:-0.5px;}}
.header .sub {{font-size:14px;opacity:0.85;margin-bottom:2px;}}
.header .sub-en {{font-size:11px;opacity:0.6;font-style:italic;}}
.main-grid {{display:grid;grid-template-columns: 1fr 1fr;gap:20px;margin-bottom:24px;}}
.main-grid .left-col {{display:flex;flex-direction:column;gap:20px;}}
.main-grid .right-col {{display:flex;flex-direction:column;gap:20px;}}
.section {{background:#fff;border-radius:var(--radius);padding:22px 24px;
           box-shadow:var(--shadow-sm);border:1px solid var(--rule);}}
.section-num {{display:inline-flex;align-items:center;justify-content:center;
               width:32px;height:32px;border-radius:50%;background:var(--gold);
               color:#fff;font-weight:800;font-size:14px;margin-right:10px;}}
.section-title {{font-size:18px;font-weight:800;color:var(--navy);display:flex;align-items:center;}}
.section-desc {{font-size:12px;color:var(--neutral);margin:6px 0 14px 42px;}}
.brain-svg-wrap {{width:100%;max-width:100%;margin:0 auto 14px;}}
.band-row {{display:flex;gap:12px;flex-wrap:wrap;margin:14px 0;}}
.formula-box {{background:var(--bg-card);border-radius:var(--radius);padding:14px 16px;
               text-align:center;margin:12px 0;font-size:16px;font-family:monospace;
               border:1px solid var(--rule);}}
.explain-box {{background:var(--bg-card);border-radius:var(--radius);padding:12px 16px;
               font-size:12px;margin-top:10px;border:1px solid var(--rule);}}
.case-note {{background:var(--gold-light);border-radius:var(--radius);padding:10px 14px;
             font-size:12px;color:var(--navy);margin-top:10px;border-left:3px solid var(--gold);white-space:pre-line;}}
table {{width:100%;border-collapse:collapse;font-size:12px;margin-top:10px;}}
th {{background:var(--navy);color:#fff;padding:6px 10px;text-align:left;font-size:12px;}}
td {{border-bottom:1px solid var(--rule);padding:6px 10px;}}
tr:hover {{background:var(--gold-pale);}}
.code-block {{background:#1e293b;color:#e2e8f0;padding:14px 16px;border-radius:var(--radius);
              font-family:monospace;font-size:12px;line-height:1.8;margin-top:10px;}}
.footer {{text-align:center;font-size:11px;color:var(--neutral);padding:20px 0 8px;
           border-top:1px solid var(--rule);margin-top:24px;}}
@media(max-width:640px) {{
  .main-grid {{grid-template-columns: 1fr;}}
  .container {{padding:16px 10px;}}
  .section {{padding:16px 14px;}}
  .band-row {{flex-direction:column;}}
}}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>{d["title"]}</h1>
    <div class="sub">{d["subtitle"]}</div>
    <div class="sub-en">{d["subtitle_en"]}</div>
    <div style="margin-top:10px;font-size:11px;opacity:0.55;">{d["version"]}</div>
  </div>

<div id="main-grid">
  <!-- Left Column: Pipeline + Interpret -->
  <div class="left-col">
    <!-- Section 1: Pipeline -->
    <div class="section">
      <div class="section-title"><span class="section-num">{pipeline["num"]}</span>{pipeline["title"]}</div>
      <div class="section-desc">{pipeline["desc"]}</div>
      <div style="display:flex;gap:14px;flex-wrap:wrap;">{pipeline_html}</div>
    </div>

    <!-- Section 2: Interpret omega -->
    <div class="section">
      <div class="section-title"><span class="section-num">{interpret["num"]}</span>{interpret["title"]}</div>
      <div class="section-desc">{interpret["desc"]}</div>
      <div class="formula-box">{interpret["formula"]}</div>
      <div class="band-row">{bands_html}</div>
      <div class="explain-box">{explanations_html}</div>
    </div>
  </div>

  <!-- Right Column: Case Study + Quick Start -->
  <div class="right-col">
    <!-- Section 3: Case Study (with brain SVG) -->
    <div class="section">
      <div class="section-title"><span class="section-num">{casestudy["num"]}</span>{casestudy["title"]}</div>
      <div class="section-desc">{casestudy["desc"]}</div>
      <div class="brain-svg-wrap">{brain_svg_html}</div>
      <table>
        <thead><tr>{''.join(f'<th>{h}</th>' for h in casestudy["table_header"])}</tr></thead>
        <tbody>{table_rows_html}</tbody>
      </table>
      <div class="case-note">{casestudy["note"]}</div>
      <div style="margin-top:8px;font-size:12px;color:var(--neutral);">{casestudy["count"]}</div>
      <div style="margin-top:6px;font-weight:700;color:var(--gold);">{casestudy["highlight"]}</div>
    </div>

    <!-- Quick Start -->
    <div class="section">
      <div class="section-title"><span style="font-size:18px;margin-right:10px;">&#9889;</span>{quickstart["title"]}</div>
      <div class="code-block">{code_html}{extra_code}</div>
    </div>
  </div>
</div>

<div class="footer">
  <span>{d["footer_left"]}</span> &nbsp;|&nbsp; <span>{d["footer_right"]}</span>
</div>
</div>
</body>
</html>'''
    return full_html


def verify_no_chinese(text):
    """Verify no Chinese characters in text (for EN version check)."""
    if re.search(r'[\u4e00-\u9fff]', text):
        return False
    return True


def main():
    # Generate EN version
    print("Generating EN HTML...")
    en_html = build_html(EN)

    en_path = OUT_DIR / "usage_guide_en.html"
    en_path.write_text(en_html, encoding="utf-8")
    print(f"  Written: {en_path}")

    # Verify no Chinese in EN version
    if not verify_no_chinese(en_html):
        print("  WARNING: Chinese characters found in EN HTML!")
    else:
        print("  Verified: No Chinese characters in EN version.")

    # Generate ZH version
    print("Generating ZH HTML...")
    zh_html = build_html(ZH)

    zh_path = OUT_DIR / "usage_guide_zh.html"
    zh_path.write_text(zh_html, encoding="utf-8")
    print(f"  Written: {zh_path}")

    print("Done.")


if __name__ == "__main__":
    main()
