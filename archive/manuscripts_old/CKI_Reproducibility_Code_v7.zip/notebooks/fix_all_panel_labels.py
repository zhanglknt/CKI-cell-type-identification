"""Fix ALL panel labels in 30_nar_figures_final.py
Content-based replacement - no line numbers needed.
Also remove tight_layout(pad=0.5) and bbox_inches='tight'.
"""
import re

fpath = r'C:\Users\KnightZ\Desktop\细胞受选择\notebooks\30_nar_figures_final.py'
with open(fpath, 'r', encoding='utf-8') as f:
    lines = f.readlines()

new_lines = []
changes = []

for i, line in enumerate(lines):
    stripped = line.rstrip('\n\r')
    
    # 1. Skip tight_layout(pad=0.5)
    if 'tight_layout(pad=0.5)' in stripped:
        changes.append(f'  REMOVED tight_layout line {i+1}')
        continue
    
    # 2. Fix bbox_inches='tight' in savefig calls
    if "bbox_inches='tight'" in stripped:
        new = stripped.replace(", bbox_inches='tight'", "")
        # Handle cases where it's mid-call
        new = new.replace(" bbox_inches='tight',", ",")
        new = new.replace(" bbox_inches='tight')", ")")
        # Clean double-commas
        new = re.sub(r',\s*,', ',', new)
        # Clean trailing comma before )
        new = re.sub(r',\s*\)', ')', new)
        if new != stripped:
            changes.append(f'  FIXED bbox_inches line {i+1}')
        new_lines.append(new + '\n')
        continue
    
    # 3. Replace panel label lines
    # Match: axX.text(NUM, NUM, '(L)', fontweight='bold', fontsize=10, transform=axX.transAxes)
    # Also: ax.text(...) inside loops
    if ('.text(' in stripped and 'fontweight' in stripped 
        and 'transAxes' in stripped):
        # Extract ax name
        ax_m = re.match(r'^(\s*)ax([A-Za-z0-9]*)\.text\(', stripped)
        # Extract letter from '(L)' or "(L)"
        letter_m = re.search(r"['\"]\(?([A-F])\)?['\"]", stripped)
        # Extract x coordinate to determine col_pos
        x_m = re.search(r'\.text\((-?[\d.]+)', stripped)
        
        if ax_m and letter_m:
            indent = ax_m.group(1)
            ax_suffix = ax_m.group(2)  # 'A', 'B', '', etc.
            letter = letter_m.group(1)
            
            # Determine col_pos from x coordinate
            col_pos = 'left'  # default
            if x_m:
                try:
                    x_val = float(x_m.group(1))
                    if abs(x_val + 0.05) < 0.02:  # x ≈ -0.05
                        col_pos = 'center'
                except ValueError:
                    pass
            
            new_line = f"{indent}add_panel_label(ax{ax_suffix}, '{letter}', col_pos='{col_pos}')"
            changes.append(f'  PANEL line {i+1}: ax{ax_suffix}({letter}) -> add_panel_label({col_pos})')
            new_lines.append(new_line + '\n')
            continue
    
    new_lines.append(line)

# Write back
with open(fpath, 'w', encoding='utf-8') as f:
    f.writelines(new_lines)

print(f'Total changes: {len(changes)}')
for c in changes:
    print(c)
