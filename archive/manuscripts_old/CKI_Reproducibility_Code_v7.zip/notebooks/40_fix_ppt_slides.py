"""
Fix PPT slides: Slide 3 (add images), Slide 10 (text color),
Slide 13 (text overflow), Slide 17 (migration arrows).
Covers both EN and ZH versions.
"""

import os
import io
import urllib.request
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pptx import Presentation
from pptx.util import Inches, Emu, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn, nsmap
from lxml import etree

BASE = r"C:\Users\KnightZ\Desktop\细胞受选择\results\figures_final"
PPT_EN = os.path.join(BASE, "CKI_Lecture_2026_v3.pptx")
PPT_ZH = os.path.join(BASE, "CKI_Lecture_2026_v3_ZH.pptx")


# ===========================
# Step 1: Generate 4 images for Slide 3
# ===========================
def generate_slide3_images():
    """Generate 4 small scientific illustration PNGs for the 4 method cards."""
    img_dir = os.path.join(BASE, "slide3_images")
    os.makedirs(img_dir, exist_ok=True)
    
    # Match each method card color
    colors = {
        "de": "#2563EB",    # blue - Differential Expression
        "pw": "#0D9488",    # teal - Pathway Enrichment
        "pt": "#F59E0B",    # amber - Pseudotime Trajectory
        "cl": "#DC2626",    # red - Clustering & Annotation
    }
    
    # 1) Differential Expression → Volcano plot miniature
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    np.random.seed(42)
    n = 200
    fc = np.random.normal(0, 1.5, n)
    pv = -np.log10(np.random.beta(0.5, 5, n) * 0.1 + 0.001)
    colors_pts = ['#94A3B8'] * n
    for i in range(n):
        if abs(fc[i]) > 1.5 and pv[i] > 2: colors_pts[i] = '#DC2626'
        elif abs(fc[i]) > 1.0 and pv[i] > 1.3: colors_pts[i] = '#2563EB'
    ax.scatter(fc, pv, c=colors_pts, s=12, alpha=0.8, edgecolors='none')
    ax.axhline(1.3, color='#D1D5DB', ls='--', lw=0.8)
    ax.axvline(-1, color='#D1D5DB', ls='--', lw=0.8)
    ax.axvline(1, color='#D1D5DB', ls='--', lw=0.8)
    ax.set_xlabel('log2FC', fontsize=7, color='#64748B')
    ax.set_ylabel('-log10(p)', fontsize=7, color='#64748B')
    ax.tick_params(labelsize=6, colors='#94A3B8')
    ax.set_title('Volcano Plot', fontsize=8, color=colors["de"], fontweight='bold')
    fig.tight_layout(pad=0.5)
    de_path = os.path.join(img_dir, "de_volcano.png")
    fig.savefig(de_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    # 2) Pathway Enrichment → bar plot of pathways
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    pathways = ['Ribosome', 'OXPHOS', 'Spliceosome', 'Cell Cycle', 'ECM', 'PI3K-Akt']
    scores = [4.2, 3.8, 2.9, 2.5, 1.8, 1.5]
    bars = ax.barh(pathways[::-1], scores[::-1], height=0.6, color=colors["pw"], alpha=0.85, edgecolor='none')
    ax.set_xlabel('Enrichment', fontsize=7, color='#64748B')
    ax.tick_params(labelsize=6, colors='#64748B')
    ax.set_title('Pathway Enrichment', fontsize=8, color=colors["pw"], fontweight='bold')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    fig.tight_layout(pad=0.5)
    pw_path = os.path.join(img_dir, "pathway_enrich.png")
    fig.savefig(pw_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    # 3) Pseudotime Trajectory → branching tree
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    np.random.seed(123)
    t = np.linspace(0, 4*np.pi, 80)
    x1 = t + np.random.normal(0, 0.15, 80)
    y1 = np.sin(t) + np.random.normal(0, 0.12, 80)
    x2 = t + np.random.normal(0, 0.15, 80)
    y2 = np.cos(t)*0.5 + 1.5 + np.random.normal(0, 0.12, 80)
    ax.scatter(x1, y1, c=t, cmap='Oranges', s=10, alpha=0.8, edgecolors='none')
    ax.scatter(x2, y2, c=t, cmap='Oranges', s=10, alpha=0.8, edgecolors='none')
    ax.set_title('Pseudotime Trajectory', fontsize=8, color=colors["pt"], fontweight='bold')
    ax.set_xticks([]); ax.set_yticks([])
    ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False); ax.spines['left'].set_visible(False)
    fig.tight_layout(pad=0.5)
    pt_path = os.path.join(img_dir, "pseudotime_traj.png")
    fig.savefig(pt_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    # 4) Clustering & Annotation → UMAP-style scatter
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    np.random.seed(99)
    clusters = {
        'A': (np.random.normal(-1, 0.4, 50), np.random.normal(1, 0.4, 50), '#DC2626'),
        'B': (np.random.normal(1.5, 0.35, 50), np.random.normal(0.5, 0.35, 50), '#2563EB'),
        'C': (np.random.normal(-0.8, 0.35, 50), np.random.normal(-1.2, 0.35, 50), '#0D9488'),
        'D': (np.random.normal(2, 0.4, 50), np.random.normal(-0.8, 0.4, 50), '#F59E0B'),
    }
    for name, (cx, cy, clr) in clusters.items():
        ax.scatter(cx, cy, c=clr, s=12, alpha=0.85, edgecolors='none', label=name)
        ax.annotate(name, (np.mean(cx), np.mean(cy)), fontsize=6, ha='center', va='center',
                   color='white', fontweight='bold')
    ax.set_title('Clustering (UMAP)', fontsize=8, color=colors["cl"], fontweight='bold')
    ax.set_xticks([]); ax.set_yticks([])
    ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False); ax.spines['left'].set_visible(False)
    fig.tight_layout(pad=0.5)
    cl_path = os.path.join(img_dir, "clustering_umap.png")
    fig.savefig(cl_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    return {"de": de_path, "pw": pw_path, "pt": pt_path, "cl": cl_path}

# Generate images
print("Generating 4 illustration images...")
image_paths = generate_slide3_images()
print(f"  Generated: {list(image_paths.values())}")


# ===========================
# Step 2: Fix PPTs
# ===========================
def fix_slide10(prs):
    """Slide 10: Fix right card title color from 0D9488 to 1E293B (EN + ZH)."""
    slide = prs.slides[9]  # 0-indexed
    targets = ["Cross-Organ Discrimination", "跨器官鉴别能力"]
    for shape in slide.shapes:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if any(t in run.text for t in targets):
                        run.font.color.rgb = RGBColor(0x1E, 0x29, 0x3B)
                        print(f"  Slide 10: Fixed right card title color → 1E293B")

def fix_slide13(prs):
    """Slide 13: Fix right card text overflow (EN + ZH)."""
    slide = prs.slides[12]
    targets = ["Basal-like", "基底样"]
    for shape in slide.shapes:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    if any(t in run.text for t in targets):
                        run.font.size = Pt(8)  # was 9pt
                        # Shrink and move up the text box
                        shape.top = shape.top - Emu(120000)
                        shape.height = shape.height + Emu(60000)
                        print(f"  Slide 13: Fixed bottom note overflow")


def fix_slide17(prs):
    """Slide 17: Add migration direction arrows on the brain image."""
    slide = prs.slides[16]
    
    # Brain image position: off=(502920, 868680), ext=(8138160, 2103120)
    img_left = 502920
    img_top = 868680
    img_width = 8138160
    img_height = 2103120
    img_right = img_left + img_width
    img_bottom = img_top + img_height
    
    # Add an arrow showing SVZ → Cortex migration path
    # SVZ is roughly lower-left, Cortex is upper-right on the image
    
    # Arrow from SVZ region to Cortex
    svz_x = int(img_left + img_width * 0.35)   # ~35% from left (SVZ area)
    svz_y = int(img_top + img_height * 0.6)     # ~60% down
    ctx_x = int(img_left + img_width * 0.65)    # ~65% from left (Cortex area)
    ctx_y = int(img_top + img_height * 0.25)    # ~25% down
    
    # Draw the migration arrow
    arrow = slide.shapes.add_connector(
        1,  # straight connector
        svz_x, svz_y, ctx_x, ctx_y
    )
    arrow.line.color.rgb = RGBColor(0xDC, 0x26, 0x26)  # red
    arrow.line.width = Pt(2.5)
    
    # Add arrowhead via XML manipulation
    ns_a = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    ln = arrow._element.find('.//{%s}ln' % ns_a)
    if ln is not None:
        tail_end = etree.SubElement(ln, '{%s}tailEnd' % ns_a)
        tail_end.set('type', 'triangle')
        tail_end.set('w', 'med')
        tail_end.set('len', 'med')
    
    # Add "SVZ" label near start
    txBox = slide.shapes.add_textbox(
        svz_x - Emu(120000), svz_y + Emu(30000),
        Emu(600000), Emu(200000)
    )
    tf = txBox.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = "SVZ"
    run.font.size = Pt(9)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0xDC, 0x26, 0x26)
    run.font.name = "Arial"
    
    # Add "Cortex" label near end
    txBox2 = slide.shapes.add_textbox(
        ctx_x + Emu(60000), ctx_y - Emu(60000),
        Emu(600000), Emu(200000)
    )
    tf2 = txBox2.text_frame
    p2 = tf2.paragraphs[0]
    run2 = p2.add_run()
    run2.text = "Cortex"
    run2.font.size = Pt(9)
    run2.font.bold = True
    run2.font.color.rgb = RGBColor(0xDC, 0x26, 0x26)
    run2.font.name = "Arial"
    
    # Add a second arrow for OPC migration direction
    opc_x = int(img_left + img_width * 0.30)
    opc_y = int(img_top + img_height * 0.55)
    ctx2_x = int(img_left + img_width * 0.75)
    ctx2_y = int(img_top + img_height * 0.15)
    
    arrow2 = slide.shapes.add_connector(
        1,
        opc_x, opc_y, ctx2_x, ctx2_y
    )
    arrow2.line.color.rgb = RGBColor(0x25, 0x63, 0xEB)  # blue
    arrow2.line.width = Pt(2.5)
    
    ln2 = arrow2._element.find(qn('a:ln'))
    if ln2 is not None:
        tail_end2 = etree.SubElement(ln2, qn('a:tailEnd'))
        tail_end2.set('type', 'triangle')
        tail_end2.set('w', 'med')
        tail_end2.set('len', 'med')
    
    print(f"  Slide 17: Added migration direction arrows (SVZ → Cortex, OPC → Cortex)")


def add_image_to_slide3(prs, card_img_map):
    """Slide 3: Add 4 illustration images to the 4 method cards."""
    slide = prs.slides[2]
    
    # Card positions (from XML analysis)
    cards = [
        {"name": "de", "left": 502920, "top": 960120, "width": 1931670, "height": 2743200},
        {"name": "pw", "left": 2571750, "top": 960120, "width": 1931670, "height": 2743200},
        {"name": "pt", "left": 4640580, "top": 960120, "width": 1931670, "height": 2743200},
        {"name": "cl", "left": 6709410, "top": 960120, "width": 1931670, "height": 2743200},
    ]
    
    for card in cards:
        img_path = card_img_map.get(card["name"])
        if not img_path or not os.path.exists(img_path):
            print(f"  Slide 3: Image not found for {card['name']}, skipping")
            continue
        
        # Place image in the lower portion of each card (below text, above bottom bar)
        # Content area starts after header (960120 + 640080 = 1600200)
        # Bottom bar is at y = 3520440
        # We'll place image between the ✗ content (~2971800) and bottom bar
        margin = 120000  # small margin from card edges
        img_left = card["left"] + margin
        img_top = card["top"] + 2100000  # ~2.1 inches down from card top
        img_width = card["width"] - 2 * margin
        img_height = 500000  # ~0.55 inches
        
        try:
            slide.shapes.add_picture(
                img_path, img_left, img_top, img_width, img_height
            )
            print(f"  Slide 3: Added {card['name']} image")
        except Exception as e:
            print(f"  Slide 3: Failed to add {card['name']}: {e}")


# Process both PPTs
for ppt_name, ppt_path in [("EN", PPT_EN), ("ZH", PPT_ZH)]:
    print(f"\n{'='*50}")
    print(f"Processing {ppt_name} PPT: {os.path.basename(ppt_path)}")
    print(f"{'='*50}")
    
    prs = Presentation(ppt_path)
    
    # Fix slide 10
    fix_slide10(prs)
    
    # Fix slide 13
    fix_slide13(prs)
    
    # Fix slide 17
    fix_slide17(prs)
    
    # Add images to slide 3
    add_image_to_slide3(prs, image_paths)
    
    # Save
    output_path = ppt_path  # overwrite original
    prs.save(output_path)
    print(f"  Saved: {output_path}")

print("\nDone! All PPT fixes applied.")
