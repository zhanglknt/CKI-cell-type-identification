"""
Fix Slide 10 omega text invisible + Slide 13 right card rainbow colors.

Issues:
  Slide 10: omega text is #FFFFFF on white card → invisible.
  Slide 13: PAM50 subtypes use all-blue gradient, should use multi-color
            like the LIHC left card for visual distinction.

v3.5.1
"""

from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor

BASE = r"C:\Users\KnightZ\Desktop\细胞受选择\results\figures_final"

# ============================================================
# SLIDE 10 FIX: omega text color
# ============================================================
# Shape [30] "omega ~ 3.2" → #2563EB (blue, matching bar)
# Shape [31] "omega ~ 8.1" → #DC2626 (red, matching bar)
S10_FIXES = {
    30: RGBColor(0x25, 0x63, 0xEB),  # omega ~ 3.2 → blue
    31: RGBColor(0xDC, 0x26, 0x26),  # omega ~ 8.1 → red
}

# ============================================================
# SLIDE 13 FIX: right card PAM50 colors
# ============================================================
# LIHC left card uses: 0D9488→2563EB→F59E0B→DC2626 (cool→warm progression)
# BRCA right card should use PAM50 biologically meaningful colors:
#   Normal-like (6.8)   → green  #059669   (least aggressive)
#   Luminal A  (8.2)    → teal   #0D9488
#   Luminal B  (10.5)   → blue   #2563EB
#   HER2-enriched (15.3)→ purple #7C3AED
#   Basal-like (22.1)   → red    #DC2626   (most aggressive)

# Mapping: shape index → (omega_text_color, bar_fill_color)
# Labels at indices [23, 26, 29, 32, 35]
# Bars at indices [24, 27, 30, 33, 36]
# Omega texts at indices [25, 28, 31, 34, 37]
# Accent bar (top stripe) [21], Accent bar summary [39], Summary bg [38]

PAM50_COLORS_EN = {
    # (label_idx, bar_idx, omega_idx, label, omega)
    (23, 24, 25, "Luminal A",     "omega = 8.2"):  RGBColor(0x0D, 0x94, 0x88),  # teal
    (26, 27, 28, "Luminal B",     "omega = 10.5"): RGBColor(0x25, 0x63, 0xEB),  # blue
    (29, 30, 31, "HER2-enriched", "omega = 15.3"): RGBColor(0x7C, 0x3A, 0xED),  # purple
    (32, 33, 34, "Basal-like",    "omega = 22.1"): RGBColor(0xDC, 0x26, 0x26),  # red
    (35, 36, 37, "Normal-like",   "omega = 6.8"):  RGBColor(0x05, 0x96, 0x69),  # green
}

PAM50_COLORS_ZH = {
    (23, 24, 25, "Luminal A",     "omega = 8.2"):  RGBColor(0x0D, 0x94, 0x88),
    (26, 27, 28, "Luminal B",     "omega = 10.5"): RGBColor(0x25, 0x63, 0xEB),
    (29, 30, 31, "HER2富集型",    "omega = 15.3"): RGBColor(0x7C, 0x3A, 0xED),
    (32, 33, 34, "基底样",        "omega = 22.1"): RGBColor(0xDC, 0x26, 0x26),
    (35, 36, 37, "正常样",        "omega = 6.8"):  RGBColor(0x05, 0x96, 0x69),
}


def fix_slide10_right(prs):
    """Fix invisible white omega text on white card."""
    slide = prs.slides[9]
    for idx, color in S10_FIXES.items():
        shape = slide.shapes[idx]
        for para in shape.text_frame.paragraphs:
            for run in para.runs:
                run.font.color.rgb = color


def fix_slide13_right(prs, color_map):
    """Apply PAM50 multi-color scheme to right card."""
    slide = prs.slides[12]

    for (label_idx, bar_idx, omega_idx, expected_label, expected_omega), color in color_map.items():
        # Verify label text
        label_shape = slide.shapes[label_idx]
        actual_label = label_shape.text_frame.text.strip()
        bar_shape = slide.shapes[bar_idx]
        omega_shape = slide.shapes[omega_idx]
        actual_omega = omega_shape.text_frame.text.strip()

        if actual_label != expected_label:
            print(f"  WARNING: label mismatch: expected '{expected_label}', got '{actual_label}'")
        if actual_omega != expected_omega:
            print(f"  WARNING: omega mismatch: expected '{expected_omega}', got '{actual_omega}'")

        # Set bar fill color
        bar_shape.fill.solid()
        bar_shape.fill.fore_color.rgb = color

        # Set omega text color to match bar
        for para in omega_shape.text_frame.paragraphs:
            for run in para.runs:
                run.font.color.rgb = color

        print(f"  {expected_label:16s} bar={color} omega_text={color}")

    # Update top accent stripe (shape 21) → use purple as the "middle" accent
    # Actually, better: use the most informative color. Let's keep the top accent
    # as a gradient-representative color. Use #7C3AED (purple) for the accent
    # stripe since PAM50 spans green→red.
    accent_stripe = slide.shapes[21]
    accent_stripe.fill.solid()
    accent_stripe.fill.fore_color.rgb = RGBColor(0x7C, 0x3A, 0xED)  # purple

    # Update summary background and text
    summary_bg = slide.shapes[38]
    summary_bg.fill.solid()
    summary_bg.fill.fore_color.rgb = RGBColor(0xF5, 0xF3, 0xFF)  # purple-50

    summary_text = slide.shapes[39]
    for para in summary_text.text_frame.paragraphs:
        for run in para.runs:
            run.font.color.rgb = RGBColor(0x7C, 0x3A, 0xED)

    # Update title color to match accent
    title = slide.shapes[22]
    for para in title.text_frame.paragraphs:
        for run in para.runs:
            run.font.color.rgb = RGBColor(0x7C, 0x3A, 0xED)

    print(f"  Accent stripe + title → #7C3AED, summary bg → F5F3FF")


def main():
    # Process EN
    print("=== Processing EN ===")
    prs_en = Presentation(f"{BASE}/CKI_Lecture_2026_v3.pptx")

    print("\nSlide 10: Fix omega text colors")
    fix_slide10_right(prs_en)

    print("\nSlide 13: Apply PAM50 multi-color scheme")
    fix_slide13_right(prs_en, PAM50_COLORS_EN)

    prs_en.save(f"{BASE}/CKI_Lecture_2026_v3.pptx")
    print("  Saved EN PPTX")

    # Process ZH
    print("\n=== Processing ZH ===")
    prs_zh = Presentation(f"{BASE}/CKI_Lecture_2026_v3_ZH.pptx")

    print("\nSlide 10: Fix omega text colors")
    fix_slide10_right(prs_zh)

    print("\nSlide 13: Apply PAM50 multi-color scheme")
    fix_slide13_right(prs_zh, PAM50_COLORS_ZH)

    prs_zh.save(f"{BASE}/CKI_Lecture_2026_v3_ZH.pptx")
    print("  Saved ZH PPTX")

    print("\n=== DONE ===")


if __name__ == "__main__":
    main()
