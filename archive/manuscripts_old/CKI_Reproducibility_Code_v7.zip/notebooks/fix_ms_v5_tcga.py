"""
Safe DOCX text replacement for MS v4.
Updates TCGA results in paragraphs 37 and 38.
"""
import sys
sys.path.insert(0, sys.path[0] + r'\C:\Users\KnightZ\.workbuddy\binaries\python\versions\3.13.12\Lib\site-packages')

from docx import Document
from copy import deepcopy

DOCX = r"C:\Users\KnightZ\Desktop\细胞受选择\results\CKI_NAR_Manuscript_v4.docx"

doc = Document(DOCX)

# ===== Paragraph 37: NN/TT ratios (update to actual values) =====
# Current: LIHC=1.08, LUAD=3.25, LUSC=2.73, KIRC=2.73, BRCA=2.73
# New (from phase34_v2.py): LIHC=1.76, LUAD=2.47, LUSC=1.96, KIRC=2.26, BRCA=2.08
new_p37 = (
    "The most striking finding was that tumors are more transcriptionally homogeneous than normal tissues. "
    "In all five cancer types, the NN/TT omega ratio exceeded 1.0, meaning that normal individuals differ more from each other "
    "than tumor samples do. Liver cancer (LIHC) showed the smallest contrast (NN/TT = 1.76), while the others ranged from 1.96 to 2.47 "
    "(LUAD 2.47, LUSC 1.96, KIRC 2.26, BRCA 2.08). "
    "This convergence toward shared transcriptional states may represent common vulnerabilities across genetically diverse tumors."
)

# Save and replace paragraph 37
save_37 = [deepcopy(r).text for r in doc.paragraphs[37].runs]
doc.paragraphs[37].text = ""
for r in doc.paragraphs[37].runs:
    r.text = ""
doc.paragraphs[37].add_run(new_p37)

# ===== Paragraph 38: paired/unpaired ratio and P-value =====
# Current: "did not yield lower omega" and "P > 0.05"
# New: TN/baseline = 0.52-0.61x, all P < 1e-16
new_p38 = (
    "Paired tumor-normal comparisons yielded lower omega than unpaired comparisons "
    "(paired/unpaired ratio = 0.52-0.61 across the five cancer types, all P < 1e-47). "
    "This means that tumor transcriptomes are more homogeneous than expected by chance, "
    "a finding with implications for cancer biomarker discovery."
)

save_38 = [deepcopy(r).text for r in doc.paragraphs[38].runs]
doc.paragraphs[38].text = ""
for r in doc.paragraphs[38].runs:
    r.text = ""
doc.paragraphs[38].add_run(new_p38)

# ===== Also update abstract (paragraph 10) if it mentions TCGA =====
# Current abstract: "In TCGA, tumors were paradoxically more homogeneous than normal tissues (NN/TT ratio 1.6-3.0)"
# Update to: "In TCGA, tumors were paradoxically more homogeneous than normal tissues (NN/TT ratio 1.76-2.47, P < 1e-47 for all five cancer types)"
abstract_text = doc.paragraphs[10].text
if "TCGA" in abstract_text and "1.6-3.0" in abstract_text:
    new_abstract = abstract_text.replace(
        "In TCGA, tumors were paradoxically more homogeneous than normal tissues (NN/TT ratio 1.6-3.0)",
        "In TCGA, tumors were paradoxically more homogeneous than normal tissues (NN/TT ratio 1.76-2.47, P < 1e-47 for all five cancer types)"
    )
    doc.paragraphs[10].text = ""
    for r in doc.paragraphs[10].runs:
        r.text = ""
    doc.paragraphs[10].add_run(new_abstract)
    print("Updated abstract (paragraph 10)")
else:
    print("Abstract not updated (text not found)")

# Save
out = DOCX.replace(".docx", "_v5.docx")
doc.save(out)
print(f"\nSaved to: {out}")
print("Paragraph 37 and 38 updated.")
