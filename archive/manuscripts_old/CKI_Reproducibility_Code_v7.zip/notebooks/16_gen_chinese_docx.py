"""
Generate Chinese-language DOCX versions of:
1. NAR Manuscript (正文)
2. Cover Letter (投稿信)
3. Supplementary Information (补充材料)

中文格式：
- 正文：宋体 小四(12pt)，1.5倍行距
- 标题：黑体，不同级别不同字号
- 一级标题：黑体 三号(16pt)
- 二级标题：黑体 小三(15pt)
- 三级标题：黑体 四号(14pt)
"""
import os, sys
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Cm, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

BASE = r"C:\Users\KnightZ\Desktop\细胞受选择\results"
OUT = {
    "manuscript": os.path.join(BASE, "CKI_NAR_正文.docx"),
    "cover": os.path.join(BASE, "CKI_NAR_投稿信.docx"),
    "supplementary": os.path.join(BASE, "CKI_NAR_补充材料.docx"),
}

FONT_BODY = "宋体"
FONT_HEADING = "黑体"
FONT_ENG = "Arial"
SIZE_BODY = 12       # 小四
SIZE_ABSTRACT = 11
SIZE_LEGEND = 10
SIZE_REF = 10
LINE_SPACING = 1.5

# ============================================================
# Utilities
# ============================================================

def set_cn_font(run, font_cn, font_en, size_pt, bold=False, italic=False):
    """Set font for Chinese text: cn font for CJK, en font for ASCII."""
    run.font.size = Pt(size_pt)
    run.font.name = font_en
    run.font.color.rgb = RGBColor(0, 0, 0)
    # Bold via XML (python-docx bug: run.bold = True silently fails)
    rPr = run._element.get_or_add_rPr()
    for old in rPr.findall(qn('w:b')):
        rPr.remove(old)
    if bold:
        b = rPr.makeelement(qn('w:b'), {})
        rPr.append(b)
    # Italic via XML
    for old in rPr.findall(qn('w:i')):
        rPr.remove(old)
    if italic:
        i = rPr.makeelement(qn('w:i'), {})
        rPr.append(i)
    rFonts = rPr.makeelement(qn('w:rFonts'), {})
    rFonts.set(qn('w:eastAsia'), font_cn)
    rFonts.set(qn('w:ascii'), font_en)
    rFonts.set(qn('w:hAnsi'), font_en)
    rPr.insert(0, rFonts)

def setup_cn_styles(doc):
    """Configure default document styles for Chinese NAR submission."""
    style = doc.styles["Normal"]
    font = style.font
    font.name = FONT_ENG
    font.size = Pt(SIZE_BODY)
    font.color.rgb = RGBColor(0, 0, 0)
    pf = style.paragraph_format
    pf.space_after = Pt(0)
    pf.space_before = Pt(0)
    pf.line_spacing = LINE_SPACING
    rPr = style.element.get_or_add_rPr()
    rFonts = rPr.makeelement(qn('w:rFonts'), {})
    rFonts.set(qn('w:eastAsia'), FONT_BODY)
    rFonts.set(qn('w:ascii'), FONT_ENG)
    rFonts.set(qn('w:hAnsi'), FONT_ENG)
    rPr.insert(0, rFonts)

def set_superscript(run):
    """Reliably set superscript via XML (more reliable than run.font.superscript)."""
    rPr = run._element.get_or_add_rPr()
    # Remove existing vertAlign if any
    for old in rPr.findall(qn('w:vertAlign')):
        rPr.remove(old)
    va = rPr.makeelement(qn('w:vertAlign'), {qn('w:val'): 'superscript'})
    rPr.append(va)


def add_title_page_cn(doc, title_text, author_entries, affil_dict, corresponding):
    """Chinese manuscript title page.

    author_entries: list of {"name": str, "supers": str (e.g. "1,2")}
    affil_dict:    dict of {num: affil_text}  e.g. {"1": "中国医学科学院...", "2": "北京脑科学与类脑研究所..."}
    """
    doc.add_paragraph()

    # Title
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run(title_text)
    set_cn_font(r, FONT_HEADING, FONT_ENG, 16, bold=True)

    doc.add_paragraph()

    # Authors — superscript numbers via XML
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.5
    for idx, entry in enumerate(author_entries):
        if idx > 0:
            r = p.add_run("，")
            set_cn_font(r, FONT_BODY, FONT_ENG, 14)
        r = p.add_run(entry["name"])
        set_cn_font(r, FONT_BODY, FONT_ENG, 14)
        if entry.get("supers"):
            for ch in entry["supers"]:
                r = p.add_run(ch)
                set_cn_font(r, FONT_BODY, FONT_ENG, 14)
                if ch.isdigit() or ch == ",":
                    set_superscript(r)
        if entry.get("corresponding"):
            r = p.add_run("*")
            set_cn_font(r, FONT_BODY, FONT_ENG, 14)

    doc.add_paragraph()

    # Affiliations — superscript numbers via XML
    for num, affil_text in affil_dict.items():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing = 1.15
        r = p.add_run(num)
        set_cn_font(r, FONT_BODY, FONT_ENG, 10)
        set_superscript(r)
        r = p.add_run(affil_text)
        set_cn_font(r, FONT_BODY, FONT_ENG, 10)

    # Corresponding note
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run("* 通讯作者: ")
    set_cn_font(r, FONT_BODY, FONT_ENG, 9, italic=True)
    r = p.add_run(corresponding)
    set_cn_font(r, FONT_BODY, FONT_ENG, 9, italic=True)

    # ORCID
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run('ORCID: 0000-0002-0698-0754')
    set_cn_font(r, FONT_BODY, FONT_ENG, 9)

    # Running title
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_before = Pt(18)
    r = p.add_run('Running title: CKI量化选择性转录重编程')
    set_cn_font(r, FONT_BODY, FONT_ENG, 9, italic=True)

    # Keywords
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.space_before = Pt(10)
    r = p.add_run('Keywords: 转录组分化, 细胞状态动力学, 选择性重塑, 脑细胞图谱, 持家基因, Ka/Ks类比')
    set_cn_font(r, FONT_BODY, FONT_ENG, 9)

    doc.add_page_break()

def add_section_cn(doc, text, level=1):
    """Add section heading with Chinese formatting."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = LINE_SPACING
    r = p.add_run(text)
    if level == 1:
        set_cn_font(r, FONT_HEADING, FONT_ENG, 16, bold=True)
    elif level == 2:
        set_cn_font(r, FONT_HEADING, FONT_ENG, 14, bold=True)
    elif level == 3:
        set_cn_font(r, FONT_HEADING, FONT_ENG, 12, bold=True)
    return p

def add_body_cn(doc, text, size=SIZE_BODY, indent=True):
    """Add Chinese body paragraph."""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = LINE_SPACING
    p.paragraph_format.space_after = Pt(0)
    if indent:
        p.paragraph_format.first_line_indent = Cm(0.74)  # 2 Chinese chars
    r = p.add_run(text)
    set_cn_font(r, FONT_BODY, FONT_ENG, size)
    return p

def add_methods_para_cn(doc, subheading, body_text):
    """Methods paragraph with bold subheading."""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = LINE_SPACING
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.first_line_indent = Cm(0.74)
    r = p.add_run(subheading + " ")
    set_cn_font(r, FONT_HEADING, FONT_ENG, SIZE_BODY, bold=True)
    r = p.add_run(body_text)
    set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_BODY)
    return p

def add_fig_legend_cn(doc, fig_title, panels):
    """Chinese figure legend."""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(fig_title + " ")
    set_cn_font(r, FONT_HEADING, FONT_ENG, SIZE_LEGEND, bold=True)
    for panel_text in panels:
        r = p.add_run(panel_text + " ")
        set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_LEGEND)

def add_ref_entry_cn(doc, ref_num, authors, title, journal, volume, pages, year):
    """Chinese-style reference entry (keep English content, Chinese number)."""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.left_indent = Cm(0.63)
    p.paragraph_format.first_line_indent = Cm(-0.63)

    r = p.add_run(f"[{ref_num}] ")
    set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_REF)
    r = p.add_run(f"{authors}. ")
    set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_REF)
    r = p.add_run(f"{title}. ")
    set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_REF)
    r = p.add_run(journal + " ")
    set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_REF, italic=True)
    r = p.add_run(volume)
    set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_REF, bold=True)
    r = p.add_run(f", {pages} ({year}).")
    set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_REF)
    return p

# ============================================================
# Chinese Manuscript
# ============================================================

def build_manuscript_cn():
    doc = Document()
    setup_cn_styles(doc)

    # --- Title Page ---
    add_title_page_cn(
        doc,
        "CKI：一种用于量化选择性转录重编程的细胞状态动力学指数",
        [
            {"name": "吴宪明", "supers": "2", "corresponding": False},
            {"name": "张力", "supers": "1,2", "corresponding": True},
        ],
        {
            "¹": "中国医学科学院 北京协和医学院 输血研究所，成都",
            "²": "北京脑科学与类脑研究所，北京",
        },
        "knightz@pumc.edu.cn"
    )

    # --- 摘要 ---
    add_section_cn(doc, "摘要")
    abstract_cn = (
        "单细胞研究经常需要比较不同细胞群体的转录组。现有方法（如距离度量和相关性分析）"
        "可以衡量两个群体有多不同，但无法解释为什么不同：观察到的差异可能反映了有意义的功能性"
        "重编程，也可能仅仅是技术噪声、随机转录或个体间生理差异造成的中性波动。"
        "本文提出细胞状态动力学指数（Cell-state Kinetic Index, CKI），将转录组变异分解为"
        "中性组分（k_n，由持家基因校准）和功能性组分（k_f，由细胞类型身份基因计算）。"
        "比值ω = k_f/k_n量化选择性转录重编程的强度，类似于分子进化中Ka/Ks比值检测自然选择。"
        "ω接近1时，差异与中性预期一致；ω远大于1时，表明存在功能性适应。"
        "我们在Tabula Muris小鼠数据（15,057个细胞）、Tabula Sapiens人类数据（108,136个细胞；6个h5ad文件合计）"
        "和TCGA泛癌数据（10,535个样本）上验证了CKI。CKI ω与四种标准距离度量均呈负相关"
        "（Spearman r = −0.36至−0.46），证明它捕获了正交的信息维度。TCGA分析揭示了肿瘤"
        "转录组比正常组织更均质（NN/TT = 1.6−3.0倍），且侵袭性乳腺癌亚型表现出最低的"
        "转录异质性。进一步地，我们将CKI应用于人脑单细胞核图谱，量化同一细胞类型在不同"
        "脑区之间的功能分化，为从转录组数据推断细胞迁移历史提供了计算框架。"
    )
    add_body_cn(doc, abstract_cn, size=SIZE_ABSTRACT)

    doc.add_page_break()

    # --- 引言 ---
    add_section_cn(doc, "引言")

    intro_paras_cn = [
        "单细胞转录组学已经彻底改变了我们在组织、物种和疾病条件下表征细胞状态的能力。"
        "比较转录组学中的基本操作——量化两个细胞群体之间的差异程度——通常使用现成的距离度量来完成："
        "欧氏距离、余弦相似度、Pearson或Spearman相关性、或Jensen-Shannon（JS）散度。"
        "这些度量在数学上便利，但在生物学上盲目：它们对所有基因表达差异一视同仁，"
        "无论这些差异反映的是具有生物学意义的功能性重编程，还是仅由技术噪声、"
        "随机转录爆发或个体水平生理变异驱动的中性背景波动。",

        "这种信号与噪声的混合具有实际后果。例如，在单细胞图谱中，转录组变异的主要来源"
        "往往不是细胞类型身份，而是个体水平或批次水平的效应，这一现象已在Human Cell Atlas"
        "和Tabula Sapiens的基准测试中得到证实。Harmony、scVI和SATURN等方法正是为了校正"
        "此类干扰变异而开发。然而，在校正之后，一个根本问题仍未得到解答：对于两个细胞群体，"
        "其转录组差异中有多大比例代表功能性适应，多大比例代表中性漂变？",

        "我们认为，这个问题在结构上与分子进化领域四十年前解决的一个问题完全相同。"
        "在比较基因组学中，Ka/Ks比值（亦记为dN/dS）将核苷酸替换速率分解为非同义替换"
        "（Ka，可能受选择压力影响）和同义替换（Ks，假定为中性）两个组分[1]。该比值已成为"
        "在分子水平检测选择压力的标准度量，其概念优雅性在于使用同义替换作为内部中性基线——"
        "同一突变过程同时产生同义和非同义变化，但只有后者能够被自然选择塑造。",

        "本文提出细胞状态动力学指数（CKI），将这一分解逻辑应用于转录组比较。"
        "CKI定义了中性偏移速率k_n（以持家基因表达差异为校准基准，捕获基线转录噪声和个体间变异）"
        "和功能转化速率k_f（以细胞类型身份基因为计算依据，捕获具有生物学意义的表达程序变化）。"
        "比值ω = k_f/k_n用于量化选择性转录重编程的强度：ω ≈ 1表示观察到的差异与中性预期一致；"
        "ω >> 1表示功能性增益超过背景变异；ω << 1表示强功能性约束。",

        "我们在三个互补尺度上验证了CKI：（1）在Tabula Muris小鼠数据[2]上的校准零行为，"
        "同一细胞群体的随机拆分产生ω ≈ 1；（2）在Tabula Sapiens人类数据[3]上的跨物种验证，"
        "证明CKI捕获了具有生物学一致性的层级结构；（3）在TCGA数据上的临床扰动分析，"
        "CKI揭示了肿瘤转录组均质化和亚型特异性异质性的意外模式。关键的是，通过与四种标准距离"
        "度量的系统比较，我们证明CKI omega捕获了与所有现有方法正交的信息维度，"
        "确立了其不是一个更好的距离度量，而是一个根本上不同的测量范式。",
    ]
    for text in intro_paras_cn:
        add_body_cn(doc, text)

    # --- 结果 ---
    add_section_cn(doc, "结果")

    # Results 1
    add_section_cn(doc, "1. CKI框架：将转录组变异分解为中性组分和功能性组分", level=2)

    r1_cn = (
        "CKI以两个细胞群体A和B为输入，每个群体表示为一个伪批量表达向量"
        "（群体内各细胞的平均表达）。计算分为三个步骤。中性偏移速率k_n通过"
        "两个群体持家（HK）基因表达谱之间的JS散度估算。持家基因在定义上"
        "在不同细胞类型和条件下维持稳定表达，是理想的中性参考。"
        "k_f通过身份基因表达谱之间的JS散度估算——身份基因是定义细胞类型特异性"
        "功能的基因。在最简配置中，身份基因是排除持家基因后的top-N高变基因（HVG）。"
        "ω = k_f/k_n。关键洞见在于k_n和k_f使用相同的距离度量（JS散度），"
        "作用于同一表达矩阵中重叠的基因集上，确保比值在内部得到了校准。"
    )
    add_body_cn(doc, r1_cn)

    r1b_cn = (
        "统计推断采用bootstrap置换检验（B = 1,000）。在两个群体间随机置换"
        "细胞标签，对每次置换重新计算ω以生成零分布。经验P值为置换ω值超过观测ω的"
        "比例，效应量以Cohen's d报告。在Tabula Muris小鼠数据（703对细胞类型，6个器官）"
        "上的参数扫描表明，纯身份基因配置（w1 = 1.0, w2 = 0.0）实现了最优性能"
        "（细胞类型区分AUC = 0.786），优于所有引入通路富集分数的配置。"
        "值得注意的是，CKI不需要外部通路数据库即可产生具有生物学意义的结果——"
        "仅将基因表达数据划分为中性和身份两个集合，即可提供充分的信号。"
    )
    add_body_cn(doc, r1b_cn)

    # Results 2
    add_section_cn(doc, "2. 小鼠单细胞图谱上的校准与验证", level=2)

    r2_cn = (
        "我们在Tabula Muris FACS数据集（SmartSeq2，15,057个细胞，6个器官，22,308个基因）"
        "上对CKI进行了校准。持家基因通过数据驱动自动检测（联合标准：检出率 > 0.9 且 CV < 30%分位数），"
        "辅以HRT Atlas[4]的1,064个跨物种持家基因为可选增强。身份基因为top-2,000高变基因（HVG），排除HK基因，"
        "在四个生物学类别中进行了15对比较。六个随机拆分对照（同一器官同一类型的细胞被随机分为两半）"
        "产生的平均ω为1.16（中位数0.65，范围0.14–2.99，n = 6），0/6对达到统计显著性"
        "（双侧bootstrap检验，均P > 0.05），证实CKI在零假设下正确识别功能等同的细胞群体。"
    )
    add_body_cn(doc, r2_cn)

    r2b_cn = (
        "ω值在生物学距离上呈明显的单调关系（均值 ± s.d.）：对照（C, 1.16 ± 1.14）"
        "< 同细胞类型跨器官（S, 2.33 ± 1.32, 4/4显著）< 异细胞类型同器官（D, 10.96 ± 1.18, "
        "3/3显著）< 异细胞类型跨器官（X, 9.77 ± 8.00, 1/2显著）。C < S < D ≈ X的梯度"
        "验证了核心假设：ω随生物学距离单调递增。组分分析显示k_f从对照到跨细胞类型比较"
        "增加约1,000倍，而k_n仅增加约100倍，确认功能性重编程是ω变异的主要驱动因素。"
    )
    add_body_cn(doc, r2b_cn)

    # Results 3
    add_section_cn(doc, "3. 跨物种扩展与正交信息捕获", level=2)

    r3_cn = (
        "我们将CKI扩展到人类Tabula Sapiens图谱（107,399个细胞，99个细胞类型条目，6个器官："
        "肝脏、肾脏、心脏、骨髓、脾脏、肺脏）[3]。使用混合方案（全局固定k_n，每对独立k_f，"
        "基于top-200差异表达基因）计算了全部4,851对比较的ω。HK基因由数据自动检测（联合标准，辅以HRT Atlas可选增强）。人类ω范围为1.35至87.69"
        "（均值21.61，中位数19.65，n = 4,851对），显著高于小鼠FACS数据（均值5.71），"
        "反映了人类图谱中更多细胞类型（99 vs. ~30）和固有的更高个体异质性"
        "（多名供体 vs. 近交系小鼠品系）。类别层级结构得以保留：同细胞类型跨器官ω"
        "（均值15.83，n = 59对）< 异细胞类型同器官ω（均值24.87，n = 4,139对），"
        "与功能结构的跨物种保守性一致。",

        "关键发现：正交维度。在相同的4,851对人类细胞类型对上，系统比较了CKI ω与四种"
        "标准距离度量。CKI ω与所有其他度量呈负相关（Spearman r，n = 4,851）："
        "vs. Raw JS r = −0.396，vs. Spearman距离 r = −0.461，vs. Cosine距离 r = −0.386，"
        "vs. Marker Jaccard距离 r = −0.358（均P < 0.001）。相反，四种标准度量间形成"
        "紧密的正相关簇（r = 0.569–0.935）。这一负相关是CKI测量转录组变异中根本不同"
        "维度的最强证据。",

        "细胞类型分类性能。CKI ω的细胞类型分类AUC（0.716）处于中等水平——"
        "高于Spearman距离（0.690），但低于余弦距离（0.887）、Raw JS散度（0.836）"
        "和Marker Jaccard距离（0.801）。这与CKI的设计一致：通过降低共享持家基因模式"
        "的权重，CKI以一部分全局转录身份检测能力换取对功能专化的敏感性。同器官效应反转。"
        "CKI ω是唯一一个SameOrgan（均值24.87，n = 4,139）> DiffOrgan（均值20.73，n = 712，"
        "双侧Mann-Whitney U检验，P < 0.001）的度量。所有四种标准度量均呈现相反模式"
        "（SameOrgan < DiffOrgan）。这一反转反映了CKI对共享微环境中功能专业化的敏感性。"
    )
    add_body_cn(doc, r3_cn)

    # Results 4
    add_section_cn(doc, "4. 临床验证：TCGA泛癌扰动分析", level=2)

    r4_cn = (
        "我们将CKI应用于五种癌症类型（LUAD、LUSC、LIHC、KIRC、BRCA[5]；共n = 10,535个样本）"
        "的TCGA bulk RNA-seq数据，量化肿瘤发生引起的转录组扰动。肿瘤-正常（TN）ω范围为72.7"
        "（LUAD配对）至98.4（BRCA配对），始终低于正常-正常（NN）基线ω（NN范围108.6–539.8）。"
        "TN/NN比值为0.46–0.60倍，表明肿瘤-正常转录组差异始终小于正常个体间变异。"
        "除LIHC外所有癌种中NN/TT超过1.5；LIHC（NN/TT = 0.60）肿瘤异质性超过正常组织异质性，"
        "符合肝细胞癌已知的极端基因组异质性。配对与非配对分析表明，配对肿瘤-正常比较"
        "并未产生比非配对更低的ω（配对/非配对比值0.83–1.13，双侧Mann-Whitney U检验，"
        "五种癌症均P > 0.05），说明个体间生理变异在bulk RNA-seq层面主导肿瘤特异性扰动。",

        "LIHC Edmondson分级分析（n = 289个肿瘤）[6]显示ω随去分化程度单调递增"
        "（均值 ± s.d.）：G1（12.4 ± 2.1）< G2（13.8 ± 2.5）< G3（14.2 ± 2.3）"
        "< G4（15.3 ± 2.8）（Jonckheere-Terpstra趋势检验，P < 0.05）。BRCA PAM50亚型"
        "分析[7]（n = 1,032个肿瘤）揭示了意外模式：基底样（Basal-like）肿瘤内ω最低"
        "（74.8 ± 12.1），而Normal-like最高（112.2 ± 18.5）（Kruskal-Wallis检验，P < 0.001），"
        "呈现出临床侵袭性与转录异质性之间的反向关系，提示侵袭性乳腺癌经历转录收敛趋向"
        "共同的增殖状态。LUAD EGFR/KRAS突变分层（n = 497）未显示显著差异"
        "（EGFR 76.2 ± 10.1，KRAS 77.7 ± 9.8，WT 70.1 ± 11.2；P = 0.23），"
        "符合已知生物学：EGFR和KRAS是通路层面的驱动因子，其下游效应受共突变、"
        "表观遗传状态和微环境背景的深度调控。"
    )
    add_body_cn(doc, r4_cn)

    # Results 5
    add_section_cn(doc, "5. 细胞类型身份的跨器官保守性", level=2)

    r5_cn = (
        "4,851对比较矩阵中包含59对同一细胞类型在不同器官中的配对，使我们能够按跨器官"
        "转录保守性对细胞类型进行排名。CKI ω范围为4.50（巨噬细胞，心脏 vs. 骨髓）至55.05"
        "（红细胞，肝脏 vs. 脾脏）（n = 59对）。免疫细胞最为保守（均值跨器官ω ± s.d.）："
        "巨噬细胞（12.1 ± 8.3，n = 11对）、CD8+ T细胞（9.1 ± 3.1，n = 4）、中性粒细胞"
        "（12.9 ± 8.9，n = 5）。这些低ω值反映了免疫细胞无论组织驻留地，共享共同的谱系、"
        "功能和激活程序。结构细胞器官特异性最强：红细胞（29.4 ± 22.1，n = 2对）、"
        "内皮细胞（26.2 ± 12.3，n = 6）。CKI ω的跨器官保守性排名与标准度量的一致性"
        "较低（Spearman r = −0.13至+0.02，n = 59），源于CKI的显式归一化："
        "即使两个群体共享相似的高表达基因集（产生高Jaccard相似性），当中性基线k_n较低时，"
        "适度的功能差异也能产生高ω值。"
    )
    add_body_cn(doc, r5_cn)

    # Results 6 — 脑区应用
    add_section_cn(doc, "6. 人脑非神经元细胞的脑区功能分化", level=2)

    r6_cn = (
        "我们将CKI应用于Siletti等人（2023）的人脑单细胞核RNA-seq图谱[11]中的"
        "非神经元细胞数据集（Nonneurons.h5ad，约888K细胞核，~100个脑区），聚焦于10种"
        "跨多个脑区共存的非神经元细胞类型：星形胶质细胞（Astrocyte）、少突胶质细胞"
        "前体细胞（OPC）、脉络丛上皮细胞（Choroid plexus）、少突胶质细胞"
        "（Oligodendrocyte）、定型少突胶质前体细胞（COP）、室管膜细胞（Ependymal）、"
        "小胶质细胞（Microglia）、成纤维细胞（Fibroblast）、血管细胞（Vascular）和"
        "Bergmann胶质细胞（Bergmann glia）。使用Scanpy标准归一化流程"
        "（normalize_total 1e4 + log1p）和自动检测的持家基因（联合标准，辅以HRT Atlas可选增强）作为中性参考。"
        "对于每种细胞类型，计算了所有成对脑区间的CKI ω值，总计31,764对比较。"
    )
    add_body_cn(doc, r6_cn)

    r6b_cn = (
        "CKI ω揭示了非神经元细胞跨脑区的7.6倍分化梯度，ω均值范围为15.97至121.77"
        "（表1）。梯度排序如下（ω均值，区域数）：Bergmann胶质细胞（15.97 ± 9.81，7个区域，"
        "n = 21对）< 血管细胞（21.54 ± 11.04，82个区域，n = 3,321对）< 成纤维细胞"
        "（25.41 ± 14.73，83个区域，n = 3,403对）< 小胶质细胞（35.37 ± 18.07，107个区域，"
        "n = 5,671对）< 室管膜细胞（39.53 ± 17.30，40个区域，n = 780对）< 定型OPC"
        "（40.03 ± 22.14，52个区域，n = 1,326对）< 少突胶质细胞（44.87 ± 19.58，108个区域，"
        "n = 5,778对）< 脉络丛上皮细胞（45.47 ± 15.11，6个区域，n = 15对）< OPC"
        "（55.42 ± 31.33，107个区域，n = 5,671对）< 星形胶质细胞（121.77 ± 74.43，"
        "108个区域，n = 5,778对）。"
    )
    add_body_cn(doc, r6b_cn)

    r6c_cn = (
        "该梯度与细胞类型的已知功能特性高度吻合。Bergmann胶质细胞和血管细胞处于梯度"
        "最底端（ω < 22），表明这些结构性和支持性细胞类型在不同脑区间保持了高度一致"
        "的转录程序，选择性功能分化极其有限。小胶质细胞（ω = 35.37）处于梯度中下段，"
        "其跨脑区保守性程度令人关注：尽管作为脑内常驻免疫细胞需要应对不同的局部微环境，"
        "其核心转录程序——包括免疫监视、突触修剪和碎片清除功能——在皮层、白质和皮层下"
        "区域间保持一致。少突胶质细胞（ω = 44.87）和OPC（ω = 55.42）处于梯度中段，"
        "反映出髓鞘形成和少突胶质细胞分化的基本程序在所有白质区域共享，但存在区域特异性的"
        "调控适应。星形胶质细胞以压倒性的ω均值（121.77）位居梯度顶端，约为最保守的"
        "Bergmann胶质细胞的7.6倍，表明星形胶质细胞在不同脑区经历了广泛的区域性功能特化"
        "——这一发现与星形胶质细胞已知的区域异质性文献高度一致[12-14]，包括区域特异性"
        "的离子稳态、神经递质再摄取和突触调控功能。"
    )
    add_body_cn(doc, r6c_cn)

    r6d_cn = (
        "结合此前跨器官保守性数据（Result §5），CKI构建了一个从免疫细胞跨器官保守"
        "（ω ~ 5–12）、血管细胞跨脑区保守（ω ~ 21.5）、免疫胶质细胞区域性适应"
        "（小胶质细胞 ω ~ 35，少突胶质细胞 ω ~ 45）、到星形胶质细胞强烈区域性分化"
        "（ω ~ 122）的连续功能分化谱系。该梯度跨度超过24倍（从巨噬细胞跨器官ω ~ 5"
        "到星形胶质细胞跨脑区ω ~ 122），不仅量化了不同细胞类型的空间功能分化程度，"
        "更为从转录组数据推断细胞迁移历史和区域性疾病易感性提供了计算框架。"
        "值得注意的是，Bergmann胶质细胞极低的ω值（15.97）与其作为小脑Purkinje细胞层"
        "特化星形胶质细胞的发育起源一致——这些细胞可能在发育早期从小脑脑室区迁移定位后，"
        "即进入转录静止状态，功能性适应极为有限。"
    )
    add_body_cn(doc, r6d_cn)

    # --- Result 6.1 迁移检测 ---
    add_section_cn(doc, "6.1 CKI检测潜在的脑区间细胞迁移事件", level=3)

    r6e_cn = (
        "为了形式化迁移推断，我们设计了一个乘法模型。"
        "对于每个（细胞类型, 脑区对）组合：期望ω = μ_ct × μ_pair / μ_grand，"
        "其中μ_ct为该细胞类型的全局ω均值，μ_pair为该脑区对的ω均值，"
        "μ_grand为全局ω均值（8.01）。乘法残差 = 观测值 / 期望值："
        "残差远小于1表明该细胞类型在该脑区对间的分化程度显著低于"
        "其自身全局可塑性和该脑区对总体散度两者的预期——"
        "这种共享转录状态可能是近期迁移或共同发育起源的信号。"
        "我们定义了三个置信层级：强信号（残差 < 0.3，ω < 15，"
        "在脑区对中ω排序第1，且脑区对中位ω > 20）、"
        "中等信号（残差 < 0.5，ω < 25）和弱信号（残差 < 0.75，ω < 35）。"
    )
    add_body_cn(doc, r6e_cn)

    r6f_cn = (
        "在31,764对跨脑区比较中，5,346对（16.83%）被分类为迁移候选："
        "强信号213个（0.67%），中等1,294个（4.07%），弱3,839个（12.09%）。"
        "按细胞类型的强信号数量分布：血管细胞（52个）、OPC（50个）、"
        "小胶质细胞（31个）、少突胶质细胞（28个）、定型OPC（23个）、"
        "星形胶质细胞（14个）、成纤维细胞（13个）、室管膜细胞（1个）、"
        "Bergmann胶质细胞（1个）。脉络丛上皮细胞无强信号。"
    )
    add_body_cn(doc, r6f_cn)

    # OPC migration
    add_section_cn(doc, "OPC迁移：文献最充分验证的案例", level=3)

    r6g_cn = (
        "OPC贡献了50/213个强信号（23.5%），是仅次于血管细胞的第二大迁移候选群。"
        "最强信号为OPC在MoRF-MoEN（延髓网状结构）与MoSR（延髓感觉中继）之间："
        "ω = 1.19，期望ω = 36.0，残差 = 0.033。两个区域均位于延髓内部——"
        "是白质束连接的相邻解剖结构。这一发现与已知的OPC迁移机制高度吻合："
        "Tsai等人（2016）证实OPC以血管为物理支架在发育中的中枢神经系统内迁移[32]，"
        "该机制已在人类皮层组织中得到确认。Akay等人（2022）发现星形胶质细胞终足"
        "形成调控OPC沿血管迁移的终止[33]。我们检测到的延髓OPC迁移走廊"
        "（ω = 1.19）代表了这些迁移路径的首个定量转录组学证据。"
    )
    add_body_cn(doc, r6g_cn)

    r6h_cn = (
        "除延髓外，OPC迁移热点图谱涵盖50个脑区对，涉及脑干（MoSR、PnAN、SpC、IC）、"
        "中脑（SN、PAG）和海马（CA1-3）。这一广泛分布与OPC的三波发育起源假说一致"
        "[34]：腹侧MGE/AEP（E12.5）→ LGE/CGE（E15.5）→ 背侧皮层前体（围产期），"
        "不同起源的OPC占据不同脑区片区但可沿白质束和血管广泛迁移。"
        "CKI提供了第一个无需谱系追踪即可在全基因组尺度上绘制这些迁移路径的计算工具。"
    )
    add_body_cn(doc, r6h_cn)

    # Astrocyte anomalous conservation
    add_section_cn(doc, "星形胶质细胞的反常保守性：相邻皮层的发育分配残留", level=3)

    r6i_cn = (
        "星形胶质细胞的全局ω最高（107.54），但矛盾性地贡献了14个强迁移信号。"
        "最强信号为A23（颞叶前部听觉联合皮层）与ITG（颞下回）之间："
        "ω = 2.60，期望ω = 63.13，残差 = 0.041——降低了24倍。"
        "两个区域均位于颞叶内部，其星形胶质细胞群体的转录组相似性远超预期。"
        "这与Endo等人（2024）的Tcf4发育分配假说一致[35]：功能相关的相邻皮层"
        "可能接收来自同一放射状胶质前体池的星形胶质细胞，留下持续的转录特征。"
        "其他反常低ω对包括A29-A30 vs. A38（ω = 11.2，残差 = 0.154）和"
        "A38 vs. M1C（ω = 12.6，残差 = 0.148），均涉及相邻的额叶和运动皮层区域。"
    )
    add_body_cn(doc, r6i_cn)

    # Bergmann glia
    add_section_cn(doc, "Bergmann胶质细胞：发育迁移的转录残留", level=3)

    r6j_cn = (
        "Bergmann胶质细胞的全局ω最低（15.97），仅有1个强信号，与其在成年小脑中"
        "高度特化、转录静止的状态一致。其与小脑和脑桥核（PnEN、PnAN）之间的低ω信号"
        "反映了小脑祖细胞的发育迁移路线：Sepp等人（2026）的人脑BG发育图谱显示[36]，"
        "BG起源于小脑室管膜区（VZ）的ASCL1+ PTF1A+前体细胞，分两波（11 PCW和"
        "≥17 PCW）放射状迁移至浦肯野细胞层。脑桥核是皮层-脑桥-小脑通路的关键中继站，"
        "与小脑胶质细胞共享发育起源可解释这些残留的转录相似性。"
    )
    add_body_cn(doc, r6j_cn)

    # Microglia
    add_section_cn(doc, "小胶质细胞：发育定植残留而非成年迁移", level=3)

    r6k_cn = (
        "小胶质细胞贡献了31个强信号，尽管目前主流观点认为成年小胶质细胞不跨区域迁移，"
        "而是通过局部自我更新维持[37]。其最强信号为DTg（背侧被盖核）与SN（黑质）之间："
        "ω = 2.61，期望ω = 19.80，残差 = 0.132。我们倾向于将其解释为发育定植残留"
        "而非成年期的主动迁移：胚胎期小胶质前体通过多个血管'热点'进入脑实质[38]，"
        "来自同一进入队列的细胞可能定植到相邻脑区并维持共享的转录程序。"
        "这一假说——CKI检测的是共享发育起源而非主动迁移——"
        "可通过谱系追踪实验直接验证。若被证实，这将代表首个从成年转录组数据"
        "推断小胶质定植路径的计算方法。"
    )
    add_body_cn(doc, r6k_cn)

    # Vascular
    add_section_cn(doc, "血管细胞：网络连续性而非细胞迁移", level=3)

    r6l_cn = (
        "血管细胞贡献了最多的强信号（52个），但这一发现需要不同的生物学解释。"
        "人脑血管是一个物理连续的管道网络，成年脑内皮细胞增殖率仅为约0.4%[39]。"
        "其跨脑区低ω值（如A44-A45 vs. VA：ω = 1.75，残差 = 0.083；"
        "MTG vs. VA：ω = 1.80，残差 = 0.108）更可能反映血管树的物理连续性："
        "共享同一动脉分支供血的脑区，其血管内皮和周细胞群体因沿血管腔的空间连续性"
        "而具有转录相似性。这是一个概念上的新发现：CKI揭示了血管网络拓扑结构"
        "对细胞转录组相似性的影响——这一信号在标准单细胞分析中被忽略。"
    )
    add_body_cn(doc, r6l_cn)

    # --- 讨论 ---
    add_section_cn(doc, "讨论")

    disc_paras_cn = [
        "CKI引入了转录组比较中的一个概念性转变：从测量绝对距离转向量化选择性重编程。"
        "核心洞见——持家基因提供了内部中性参考，类似于Ka/Ks分析中的同义替换[1]——"
        "使得可以将转录组变异分解为具有不同生物学解释的组分。",

        "CKI是一个扰动指数，而非分类器。系统比较表明ω并非针对细胞类型分类优化"
        "（AUC = 0.716，高于Spearman距离的0.690但低于余弦距离的0.887），这是有意为之：细胞类型分类是一个"
        "已解决的问题；CKI回答的是互补问题——无论细胞类型标签如何，两个细胞状态之间"
        "发生了多少选择性重编程。CKI与所有标准度量的负相关证实了其捕获了现有方法"
        "无法获得的信息。",

        "Ka/Ks类比在概念上是富有成效的，但并非精确等同。关键区别包括：（1）Ka/Ks"
        "作用于具有明确位点模型的序列比对，而CKI作用于连续表达向量，需要分布层面的比较；"
        "（2）Ka/Ks中的中性参考（同义位点）在遗传密码中有机制基础，而持家基因是"
        "经验性定义的，可能因组织背景而异（通过数据驱动标准自动检测）；（3）Ka/Ks值通过显式进化模型（如PAML[8]）"
        "解释，而CKI使用经验bootstrap推断。这些差异指明了未来理论发展的方向。",

        "跨器官和跨脑区分析将CKI确立为一种在多空间尺度上测量功能分化的通用工具。"
        "脑区分析揭示了非神经元细胞的7.6倍跨脑区ω梯度（Bergmann胶质细胞15.97至星形胶质"
        "细胞121.77），与已知的星形胶质细胞区域异质性[12-14]高度吻合。"
        "关键的是，通过识别观测ω显著低于乘法期望值的细胞类型/脑区对组合，"
        "CKI检测到213个强迁移候选信号。OPC的结果得到了有关血管引导OPC迁移[32,33]的"
        "大量文献的验证——延髓OPC走廊（ω = 1.19）为这条迁移路径提供了首个定量转录组学"
        "确认。小胶质细胞的发现虽然与成年小胶质不迁移的主流观点矛盾[37]，"
        "但可能反映了CKI检测的是共享的发育定植路径——"
        "这一假说可通过谱系追踪实验验证。血管细胞的发现引入了一个新概念："
        "血管网络拓扑结构施加的转录组相似性。综合来看，这些结果确立了CKI"
        "作为从静态转录组数据推断迁移历史的工具，"
        "为谱系追踪和发育研究提供了正交的计算读出面。",

        "TCGA的泛癌发现——肿瘤转录组比正常组织更均质（NN/TT > 1.5）——对癌症生物学"
        "具有启示意义：如果肿瘤尽管具有多样的遗传背景，但趋向于共享转录状态，则这种收敛"
        "可能代表共同脆弱点。PAM50亚型分析进一步表明，这种收敛在侵袭性亚型"
        "（Basal-like, HER2）中尤为显著，可能反映了增殖程序对组织特异性表达的主导作用。",

        "局限性包括：CKI目前运行在伪批量水平，单细胞级别扩展需解决稀疏性和dropout问题；"
        "持家基因集的选择可能影响结果（CKI默认使用数据驱动自动检测，辅以HRT Atlas[4]为可选增强，组织特异性持家基因优化"
        "可能提高灵敏度）；TCGA分析受限于bulk RNA-seq分辨率，单细胞或空间转录组数据可实现"
        "更精细的扰动定量；当前实现仅以持家基因作为中性组分，引入RNA velocity剪接动力学"
        "和物种效应归一化尚待未来工作。未来方向包括发育生物学（量化发育阶段间的功能分化）、"
        "药物响应分析（测量药物诱导的转录组变化的选择性）、衰老研究（追踪年龄相关的"
        "中性vs.功能性转录变化）以及跨物种进化细胞生物学（量化生命之树上细胞类型程序的"
        "保守性和分化性）。",
    ]
    for text in disc_paras_cn:
        add_body_cn(doc, text)

    # --- 材料与方法 ---
    add_section_cn(doc, "方法")

    add_methods_para_cn(doc, "CKI计算",
        "原始计数矩阵经文库大小归一化（每细胞10,000 counts）和log1p转换。"
        "伪批量计算将细胞按细胞类型注释分组（每组至少10个细胞），计算平均表达向量。"
        "持家基因通过数据驱动自动检测（联合标准：检出率 > 0.9 且 CV < 30%分位数），并辅以HRT Atlas v1.0共识集[4]（1,130个人鼠共享HK基因）为可选增强"
        "的基因符号。给定伪批量向量μ_A和μ_B：k_n = JS(softmax(μ_A[H]), softmax(μ_B[H]))，"
        "其中H为HK基因索引集，softmax(x) = exp(x)/Σexp(x)将表达向量转换为概率分布，"
        "JS(p,q)为以2为底的对数Jensen-Shannon散度，取值[0,1]。"
        "k_f = JS(softmax(μ_A[I]), softmax(μ_B[I]))，其中I为排除HK基因后按伪批量表达"
        "top-2,000高变基因（HVG），排除HK基因。ω = k_f/k_n，上限截断为1,000。Phase 3.3混合方案中，"
        "k_n全局计算一次，k_f逐对计算。"
    )

    add_methods_para_cn(doc, "Bootstrap置换检验",
        "在两个群体间随机置换细胞标签（B = 1,000），重新计算伪批量向量和ω_null。"
        "经验P值 = (count(ω_null ≥ ω_obs) + 1)/(B + 1)。"
        "Cohen's d = (ω_obs − mean(ω_null))/s.d.(ω_null)。显著性阈值：P < 0.05"
        "（适当时采用Benjamini-Hochberg校正）。"
    )

    add_methods_para_cn(doc, "数据集",
        "Tabula Muris FACS SmartSeq2[6]：15,057个细胞，22,308个基因，6个器官"
        "（肝、心、脾、骨髓、肺、肾），QC后保留32个细胞类型条目（每组≥10个细胞）。"
        "Tabula Sapiens v1.0[7]：108,136个细胞（6个h5ad文件合计），51,852个基因，6个器官（Liver, Kidney, "
        "Heart, Bone_Marrow, Spleen, Lung），99个细胞类型条目，通过CZ CELLxGENE Discover[27]访问。"
        "TCGA bulk RNA-seq：5种癌症类型（LUAD, LUSC, LIHC, KIRC, BRCA）[8-10]，"
        "来自NCI GDC，通过TCGAbiolinks[28]和cBioPortal[29] API获取；"
        "FPKM定量，log2(x+1)转换。PAM50分类[21,22]：1,032个BRCA肿瘤，最近质心分类"
        "（Pearson相关，44/47个PAM50基因匹配）。LIHC Edmondson-Steiner分级[20]："
        "cBioPortal获取289个肿瘤。LUAD突变：cBioPortal获取497个样本。"
        "人脑图谱[11]：Siletti等人（2023）单核RNA-seq非神经元数据集（Nonneurons.h5ad），"
        "约888K细胞核，~100个脑区（roi），通过CZ CELLxGENE Discover访问。QC后保留10种"
        "细胞类型（supercluster_term）：星形胶质细胞（Astrocyte）、少突胶质细胞前体细胞"
        "（OPC）、脉络丛上皮细胞（Choroid plexus）、少突胶质细胞（Oligodendrocyte）、"
        "定型少突胶质前体细胞（COP）、室管膜细胞（Ependymal）、小胶质细胞（Microglia）、"
        "成纤维细胞（Fibroblast）、血管细胞（Vascular）和Bergmann胶质细胞（Bergmann glia）。"
        "使用Scanpy normalize_total（1e4）+ log1p归一化。伪批量按（脑区, 细胞类型）分组构建。"
        "持家基因由数据自动检测（联合标准），辅以HRT Atlas v1.0共识集[4]中1,115个匹配基因。逐对身份基因"
        "选择：每对（脑区对）按|μ_i − μ_j|排序的top-200差异表达基因（排除HK基因）。"
    )

    add_methods_para_cn(doc, "方法学比较",
        "在n = 4,851对Tabula Sapiens人类细胞类型对上计算五种度量："
        "CKI ω（混合方案）、Raw JS散度（全部基因）、Spearman距离（1 − ρ）、"
        "Cosine距离（1 − cos θ）、Marker Jaccard距离（top-200表达基因的1 − Jaccard指数）。"
        "计算全部4,851对间的度量间Spearman相关和细胞类型区分ROC-AUC。"
    )

    add_methods_para_cn(doc, "计算环境",
        "Python 3.12，scanpy ≥1.9.0，scipy ≥1.10.0，numpy ≥1.23.0，pandas ≥1.5.0，"
        "matplotlib ≥3.6.0，seaborn ≥0.12.0，scikit-learn ≥1.2.0。所有随机种子固定为42。"
    )

    add_methods_para_cn(doc, "统计报告",
        "汇总统计量以均值 ± s.d.（范围）或中位数[IQR]报告。箱线图显示中位数（中心线）、"
        "四分位距（IQR，箱体）和1.5倍IQR须线，超出须线的单个数据点标记为离群值。"
        "全文均使用双侧检验，除非另有说明。Bootstrap推断使用B = 1,000次置换；"
        "经验P值采用+1伪计数公式以避免P = 0。注：当前分析中未系统施加多重检验校正，"
        "所有报告的P值为原始bootstrap P值。效应量以Cohen's d报告：d > 0.8表示大效应量。"
        "相关系数（Spearman ρ）报告附带P值；多重相关使用BH校正。"
        "综合检验（Kruskal-Wallis、Jonckheere-Terpstra）使用P < 0.05，不附加额外校正。"
    )

    # --- 数据可用性 ---
    add_section_cn(doc, "数据可用性")
    add_body_cn(doc,
        "Tabula Muris数据可从GEO获取（GSE109774）。Tabula Sapiens数据可从CZ CELLxGENE "
        "Discover获取（https://cellxgene.cziscience.com/collections）。TCGA数据可从NCI "
        "基因组数据共享平台获取（https://portal.gdc.cancer.gov/）。HRT Atlas持家基因数据（可选参考集）"
        "可从https://www.housekeeping.unicamp.br获取。PAM50质心数据来自Parker等人[7]。"
        "可复现所有分析的已处理数据文件包含在随附代码库中。"
    )

    # --- 基金支持 ---
    add_section_cn(doc, "基金支持")
    add_body_cn(doc,
        "本研究得到中国医学科学院和北京协和医学院的支持。"
    )

    # --- 代码可用性 ---
    add_section_cn(doc, "代码可用性")
    add_body_cn(doc,
        "CKI Python软件包（v0.1.0）及所有分析脚本可在GitHub获取"
        "（https://github.com/zhanglknt/CKI-cell-type-identification）。"
        "软件包以MIT许可证发布（版本 v1.0.0）。包含复现图2关键结果的"
        "教程notebook。所有分析脚本按notebooks/目录组织，附文档说明。"
    )

    # --- 参考文献 ---
    add_section_cn(doc, "参考文献")

    refs = [
        ("1", "Regev, A. et al.",
         "The Human Cell Atlas",
         "eLife", "6", "e27041", "2017"),
        ("2", "Tabula Sapiens Consortium",
         "The Tabula Sapiens: A multiple-organ, single-cell transcriptomic atlas of humans",
         "Science", "376", "eabl4896", "2022"),
        ("3", "Luecken, M. D. & Theis, F. J.",
         "Current best practices in single-cell RNA-seq analysis: a tutorial",
         "Mol. Syst. Biol.", "15", "e8746", "2019"),
        ("4", "Nei, M. & Gojobori, T.",
         "Simple methods for estimating the numbers of synonymous and nonsynonymous nucleotide substitutions",
         "Mol. Biol. Evol.", "3", "418–426", "1986"),
        ("5", "Hounkpe, B. W., Chenou, F., de Lima, F. & De Paula, E. V.",
         "HRT Atlas v1.0 database: redefining human and mouse housekeeping genes",
         "Nucleic Acids Res.", "49", "D947–D955", "2021"),
        ("6", "Tabula Muris Consortium",
         "Single-cell transcriptomics of 20 mouse organs creates a Tabula Muris",
         "Nature", "562", "367–372", "2018"),
        ("7", "Tabula Sapiens Consortium",
         "The Tabula Sapiens: A multiple-organ, single-cell transcriptomic atlas of humans",
         "Science", "376", "eabl4896", "2022"),
        ("8", "Cancer Genome Atlas Research Network",
         "Comprehensive molecular profiling of lung adenocarcinoma",
         "Nature", "511", "543–550", "2014"),
        ("9", "Weinstein, J. N. et al.",
         "The Cancer Genome Atlas Pan-Cancer analysis project",
         "Nat. Genet.", "45", "1113–1120", "2013"),
        ("10", "Cancer Genome Atlas Network",
         "Comprehensive molecular portraits of human breast tumours",
         "Nature", "490", "61–70", "2012"),
        ("11", "Siletti, K. et al.",
         "Transcriptomic diversity of cell types across the adult human brain",
         "Science", "382", "eadd7046", "2023"),
        ("12", "Tran, H. T. N. et al.",
         "A benchmark of batch-effect correction methods for single-cell RNA sequencing data",
         "Genome Biol.", "21", "12", "2020"),
        ("13", "Korsunsky, I. et al.",
         "Fast, sensitive and accurate integration of single-cell data with Harmony",
         "Nat. Methods", "16", "1289–1296", "2019"),
        ("14", "Lopez, R., Regier, J., Cole, M. B., Jordan, M. I. & Yosef, N.",
         "Deep generative modeling for single-cell transcriptomics",
         "Nat. Methods", "15", "1053–1058", "2018"),
        ("15", "Rosen, Y. et al.",
         "Universal cell type embeddings from single-cell atlases using protein language models",
         "Nat. Methods", "21", "881–892", "2024"),
        ("16", "Lin, J.",
         "Divergence measures based on the Shannon entropy",
         "IEEE Trans. Inf. Theory", "37", "145–151", "1991"),
        ("17", "Efron, B.",
         "Bootstrap methods: another look at the jackknife",
         "Ann. Stat.", "7", "1–26", "1979"),
        ("18", "Benjamini, Y. & Hochberg, Y.",
         "Controlling the false discovery rate: a practical and powerful approach to multiple testing",
         "J. R. Stat. Soc. B", "57", "289–300", "1995"),
        ("19", "Wolf, F. A., Angerer, P. & Theis, F. J.",
         "SCANPY: large-scale single-cell gene expression data analysis",
         "Genome Biol.", "19", "15", "2018"),
        ("20", "Edmondson, H. A. & Steiner, P. E.",
         "Primary carcinoma of the liver: a study of 100 cases among 48,900 necropsies",
         "Cancer", "7", "462–503", "1954"),
        ("21", "Perou, C. M. et al.",
         "Molecular portraits of human breast tumours",
         "Nature", "406", "747–752", "2000"),
        ("22", "Parker, J. S. et al.",
         "Supervised risk predictor of breast cancer based on intrinsic subtypes",
         "J. Clin. Oncol.", "27", "1160–1167", "2009"),
        ("23", "Yang, Z.",
         "PAML 4: phylogenetic analysis by maximum likelihood",
         "Mol. Biol. Evol.", "24", "1586–1591", "2007"),
        ("24", "Tarashansky, A. J. et al.",
         "Mapping single-cell atlases throughout Metazoa unravels cell type evolution",
         "eLife", "10", "e66747", "2021"),
        ("25", "Jiang, J. et al.",
         "CACIMAR: cross-species analysis of cell identities, markers, regulations, and interactions",
         "Brief. Bioinform.", "25", "bbae283", "2024"),
        ("26", "Hao, Y. et al.",
         "Integrated analysis of multimodal single-cell data",
         "Cell", "184", "3573–3587", "2021"),
        ("27", "Megill, C. et al.",
         "cellxgene: a performant, scalable exploration platform for high dimensional sparse matrices",
         "bioRxiv", "", "2021.04.05.438318", "2021"),
        ("28", "Colaprico, A. et al.",
         "TCGAbiolinks: an R/Bioconductor package for integrative analysis of TCGA data",
         "Nucleic Acids Res.", "44", "e71", "2016"),
        ("29", "Cerami, E. et al.",
         "The cBio Cancer Genomics Portal: an open platform for exploring multidimensional cancer genomics data",
         "Cancer Discov.", "2", "401–404", "2012"),
        ("30", "Pedregosa, F. et al.",
         "Scikit-learn: machine learning in Python",
         "J. Mach. Learn. Res.", "12", "2825–2830", "2011"),
        ("31", "Liberzon, A. et al.",
         "The Molecular Signatures Database Hallmark Gene Set Collection",
         "Cell Syst.", "1", "417–425", "2015"),
        ("32", "Lin, Z. et al.",
         "Evolutionary-scale prediction of atomic-level protein structure with a language model",
         "Science", "379", "1123–1130", "2023"),
        ("33", "La Manno, G. et al.",
         "RNA velocity of single cells",
         "Nature", "560", "494–498", "2018"),
        # 34. Menassa 2022 Dev Cell — microglia across lifespan
        ("34", "Menassa, D. A. et al.",
         "The spatiotemporal dynamics of microglia across the human lifespan",
         "Dev. Cell", "57", "1910–1927", "2022"),
        # 35. Wälchli 2024 Nature — brain vasculature atlas
        ("35", "Wälchli, T. et al.",
         "Single-cell atlas of the human brain vasculature across development, adulthood and disease",
         "Nature", "632", "603–613", "2024"),
        # 36. Hao 2024 Nat Biotechnol — Seurat v5
        ("36", "Hao, Y. et al.",
         "Dictionary learning for integrative, multimodal and scalable single-cell analysis",
         "Nat. Biotechnol.", "42", "293–304", "2024"),
    ]
    for ref in refs:
        add_ref_entry_cn(doc, *ref)

    # --- 致谢 ---
    add_section_cn(doc, "致谢")
    add_body_cn(doc,
        "作者感谢Tabula Muris联盟、Tabula Sapiens联盟和TCGA研究网络公开提供其数据。"
        "本研究得到中国医学科学院和北京协和医学院的支持。"
    )

    # --- 作者贡献 ---
    add_section_cn(doc, "作者贡献")
    add_body_cn(doc,
        "X.W.与L.Z.共同构思了本研究并设计了计算框架。L.Z.开发了CKI算法，执行了全部分析并准备了所有图片。"
        "X.W.参与了数据管理、验证和稿件撰写。两位作者已阅读并批准最终稿件。"
    )

    # --- 利益冲突声明 ---
    add_section_cn(doc, "利益冲突声明")
    add_body_cn(doc, "作者声明不存在竞争性经济利益。")

    doc.add_page_break()

    # --- 图注 ---
    add_section_cn(doc, "图注")

    fig1 = (
        "图1. CKI框架。",
        [
            "(a) Ka/Ks分子进化与CKI转录组学之间的概念类比。在Ka/Ks分析中，"
            "同义替换速率Ks作为中性基线；ω = Ka/Ks > 1表示正选择。在CKI中，"
            "持家基因散度提供k_n，身份基因散度提供k_f；ω = k_f/k_n > 1表示"
            "选择性转录重编程。(b) 计算流程：原始计数矩阵 → 伪批量 → "
            "持家基因JS散度(k_n)与身份基因JS散度(k_f) → ω。"
            "(c) Bootstrap置换检验：细胞标签随机置换（B = 1,000）生成零分布；"
            "经验P值 = 零分布ω ≥ 观测ω的比例。",
        ]
    )
    add_fig_legend_cn(doc, *fig1)

    fig2 = (
        "图2. CKI在Tabula Muris小鼠数据上的校准与验证。",
        [
            "(a) 四个比较类别的ω值。对照(C)：随机拆分，n = 6，均值 = 1.16 ± 1.14。"
            "同CT跨器官(S)：n = 4，均值 = 2.33 ± 1.32。异CT同器官(D)：n = 3，"
            "均值 = 10.96 ± 1.18。异CT跨器官(X)：n = 2，均值 = 9.77 ± 8.00。"
            "箱线图：中线为中位数，箱体为IQR，须线为1.5× IQR。"
            "(b) 跨类别k_n与k_f组分分解，显示k_f从C至D增加约1,000倍，"
            "而k_n仅增加约100倍。(c) 六组对照比较的Bootstrap零分布（各B = 1,000），"
            "均集中在ω = 1附近且P值不显著（均P > 0.05，双侧）。"
            "(d) 肝细胞 vs. 肝窦内皮细胞代表性逐基因JS散度图"
            "（D类，ω = 12.31），突出身份基因相对持家基因的选择性散度。",
        ]
    )
    add_fig_legend_cn(doc, *fig2)

    fig3 = (
        "图3. CKI捕获正交信息维度。",
        [
            "(a) n = 4,851对Tabula Sapiens人类细胞类型对五种转录组距离度量的"
            "Spearman相关热图。CKI ω与所有四种标准度量呈负相关"
            "（r = −0.36至−0.46，均P < 0.001）；标准度量形成正相关簇"
            "（r = 0.57–0.94）。(b) CKI ω vs. 各标准度量的散点图，"
            "按比较类别着色。(c) 细胞类型分类ROC曲线（n = 4,851对）："
            "cosine距离 AUC = 0.887，raw JS AUC = 0.836，"
            "marker Jaccard AUC = 0.801，CKI ω AUC = 0.716，Spearman AUC = 0.690。"
            "(d) SameOrgan/DiffOrgan比较。CKI ω是唯一SameOrgan（均值24.87 ± 8.5，"
            "n = 4,139）> DiffOrgan（均值20.73 ± 9.2，n = 712，"
            "双侧Mann-Whitney U检验，P < 0.001）的度量。柱状图为均值；误差线为s.d.。",
        ]
    )
    add_fig_legend_cn(doc, *fig3)

    fig4 = (
        "图4. TCGA泛癌扰动分析。",
        [
            "(a) 五种癌症类型（LUAD, LUSC, LIHC, KIRC, BRCA）的TT、NN、"
            "配对TN和非配对TN比较的ω值。五种癌症中的四种NN > TT（NN/TT = 1.6–3.0倍）。"
            "TN/配对比值 = 0.83–1.13，不显著（双侧Mann-Whitney U检验，均P > 0.05）。"
            "(b) BRCA PAM50亚型肿瘤内ω（TT）（均值 ± s.d.）：Basal-like（74.8 ± 12.1, "
            "n = 181），HER2（82.5 ± 13.5, n = 67），Luminal A（94.3 ± 15.2, n = 434），"
            "Luminal B（89.1 ± 14.8, n = 314），Normal-like（112.2 ± 18.5, n = 36）。"
            "Kruskal-Wallis检验，P < 0.001。(c) LIHC Edmondson分级（均值 ± s.d.）："
            "G1（12.4 ± 2.1, n = 12），G2（13.8 ± 2.5, n = 118），"
            "G3（14.2 ± 2.3, n = 127），G4（15.3 ± 2.8, n = 32）。"
            "Jonckheere-Terpstra趋势检验，P < 0.05。"
            "(d) LUAD突变分层（均值 ± s.d.）：EGFR突变（76.2 ± 10.1, n = 61），"
            "KRAS突变（77.7 ± 9.8, n = 121），WT（70.1 ± 11.2, n = 312）。"
            "Kruskal-Wallis检验，P = 0.23；n.s.，不显著。",
        ]
    )
    add_fig_legend_cn(doc, *fig4)

    fig5 = (
        "图5. 细胞类型身份的跨器官保守性。",
        [
            "(a) 59对同一CT跨器官配对的CKI ω排名（Tabula Sapiens）。"
            "免疫细胞类型（巨噬细胞：均值12.1 ± 8.3, n = 11；CD8+ T：均值9.1 ± 3.1, "
            "n = 4；中性粒细胞：均值12.9 ± 8.9, n = 5）占据最低位置。"
            "结构细胞（红细胞：均值29.4 ± 22.1, n = 2；内皮细胞：均值26.2 ± 12.3, "
            "n = 6）显示最高ω。柱状图按细胞类型类别着色。"
            "(b) CKI ω与标准度量的跨器官保守性排名比较（n = 59对）："
            "r = −0.13（Raw JS），r = −0.06（Spearman），r = 0.02（Cosine），"
            "r = −0.09（Jaccard）。虚线为恒等线。"
            "(c) 选定细胞类型跨器官配对的CKI ω热图，按层次聚类组织"
            "（平均连接，Spearman距离）。",
        ]
    )
    add_fig_legend_cn(doc, *fig5)

    fig6 = (
        "图6. 人脑非神经元细胞的脑区功能分化与迁移推断。",
        [
            "(a) 10种非神经元细胞类型跨脑区成对CKI ω热图（31,764对），按层次聚类组织"
            "（平均连接，Spearman距离）。色阶表示ω值范围，深色表示高ω（强分化），"
            "浅色表示低ω（保守）。(b) 不同细胞类型的跨脑区ω分布箱线图，展示7.6倍分化梯度："
            "Bergmann胶质细胞（ω = 15.97 ± 9.81）< 血管细胞（21.54 ± 11.04）"
            "< 成纤维细胞（25.41 ± 14.73）< 小胶质细胞（35.37 ± 18.07）"
            "< 室管膜细胞（39.53 ± 17.30）< 定型OPC（40.03 ± 22.14）"
            "< 少突胶质细胞（44.87 ± 19.58）< 脉络丛（45.47 ± 15.11）"
            "< OPC（55.42 ± 31.33）< 星形胶质细胞（121.77 ± 74.43）。"
            "横线为中位数，箱体为IQR，须线为1.5×IQR。"
            "(c) 各细胞类型的区域覆盖度（区域数）与ω均值的关系散点图，"
            "显示区域覆盖度与分化程度无显著相关，排除了采样偏差对梯度的影响。"
            "(d) 迁移候选检测：31,764对全部比较的观测ω vs. 期望ω散点图，"
            "213个强信号候选（残差 < 0.3）以红色高亮。标注三个最显著候选："
            "OPC MoRF-MoEN vs. MoSR（ω = 1.19）、星形胶质细胞 A23 vs. ITG"
            "（ω = 2.60）、小胶质细胞 DTg vs. SN（ω = 2.61）。"
            "(e) 各细胞类型强迁移信号候选数量柱状图，"
            "OPC（50）和血管细胞（52）为最活跃的迁移细胞类别。",
        ]
    )
    add_fig_legend_cn(doc, *fig6)

    doc.add_page_break()

    # --- 扩展数据图注 ---
    add_section_cn(doc, "扩展数据图注")

    ed_items_cn = [
        ("扩展数据图1. 参数扫描与通路分析。",
         "(a) 多组分k_f权重扫描结果（w1 = Δidentity, w2 = Δpathway）。"
         "纯身份基因（w1 = 1.0, w2 = 0.0）实现最优AUC = 0.786。"
         "n = 703对小鼠细胞类型，6个器官。"
         "(b) 32个细胞类型伪批量在50个MSigDB Hallmark基因集上的通路富集分数（ssGSEA）。"
         "数据见补充表1。"),
        ("扩展数据图2. 跨物种验证详情。",
         "(a) 基于CKI ω的99个人类细胞类型层次聚类树状图（平均连接，Spearman距离），"
         "显示按细胞谱系而非器官来源的预期分组。(b) 小鼠（n = 15对）和人类"
         "（n = 4,851对）ω分布叠加，展示人类ω更高（均值21.61 vs. 5.71）但层级结构保持一致。"),
        ("扩展数据图3. TCGA各癌种分层详情。",
         "(a) LUAD, LUSC, LIHC, KIRC, BRCA各癌种成对ω矩阵，标注TT, NN, TN区块。"
         "色阶：ω 0–200，蓝-白-红色谱。(b) 五种癌症类型的NN/TT比值；"
         "四种癌症NN/TT > 1.5，LIHC NN/TT = 0.60。误差线：bootstrap 95% CI (B = 1,000)。"
         "(c) BRCA PAM50质心距离矩阵，确认Basal-like与Luminal亚型的清晰分离。"),
        ("扩展数据图4. 方法学比较性能。",
         "五种距离度量的细胞类型分类ROC-AUC柱状图（n = 4,851对）。"
         "Cosine: 0.887, Raw JS: 0.836, Jaccard: 0.801, CKI ω: 0.716, Spearman: 0.690。"
         "误差线：1,000次bootstrap重采样95% CI。"),
        ("扩展数据图5. 跨器官保守性原始数据。",
         "59对同一CT跨器官配对的完整数据表，含ω, JS, Spearman, Cosine和Jaccard值。"
         "数据见补充表2。"),
        ("扩展数据图6. 脑区分析详情。",
         "(a) Siletti等人（2023）人脑图谱的脑区取样图谱（~100个ROI）。"
         "(b) 各脑区非神经元细胞类型组成（10种细胞类型 × 脑区矩阵）。"
         "(c) 全部31,764对跨脑区CKI ω矩阵（10种细胞类型），按细胞类型聚类。"
         "(d) 各细胞类型的ω分布直方图，展示偏态分布和尾部特征。"
         "(e) k_n与k_f的组分分解：k_f是ω变异的主要驱动因素（均值0.03-0.14），"
         "k_n维持低水平（均值0.0008-0.0035），验证CKI框架中功能性重编程主导变异的假设。"),
        ("扩展数据图7. 迁移候选分析。",
         "(a) 31,764对比较的乘法残差分布，以不同颜色标示强（残差 < 0.3）、"
         "中等（残差 < 0.5）和弱（残差 < 0.75）三个置信层级。"
         "(b) 按细胞类型分层的迁移候选数量，按置信层级堆叠。"
         "(c) 按残差排序的前30强迁移候选，标注细胞类型和脑区对标识。"
         "(d) 全脑迁移热点图谱：所有细胞类型汇总的强候选数量邻接矩阵，"
         "显示脑干、海马和颞叶皮层为主要迁移轴线。"
         "(e) 文献验证概要：OPC血管引导迁移（Tsai 2016, Akay 2022）、"
         "Bergmann胶质细胞发育迁移（Sepp 2026）、星形胶质细胞Tcf4介导分配"
         "（Endo 2024）及小胶质细胞发育定植路径（Menassa 2022）。"),
    ]
    for ed_title, ed_text in ed_items_cn:
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.5
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ed_title)
        set_cn_font(r, FONT_HEADING, FONT_ENG, SIZE_LEGEND, bold=True)
        r = p.add_run(ed_text)
        set_cn_font(r, FONT_BODY, FONT_ENG, SIZE_LEGEND)

    doc.save(OUT["manuscript"])
    print(f"Saved: {OUT['manuscript']}")

# ============================================================
# Chinese Cover Letter
# ============================================================

def build_cover_letter_cn():
    doc = Document()
    setup_cn_styles(doc)

    # Date
    p = doc.add_paragraph()
    r = p.add_run("2026年5月23日")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    doc.add_paragraph()

    # Addressee
    p = doc.add_paragraph()
    r = p.add_run("致：Nucleic Acids Research 编辑委员会")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    doc.add_paragraph()

    # Salutation
    p = doc.add_paragraph()
    r = p.add_run("尊敬的编辑：")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    doc.add_paragraph()

    # Opening
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.5
    r = p.add_run("谨向贵刊投稿题为《")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)
    r = p.add_run("CKI：一种受Ka/Ks启发、用于单细胞转录组学中细胞类型鉴定的指数")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11, italic=True)
    r = p.add_run("》的论文，恳请审阅。")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    # Summary
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    r = p.add_run("研究概要")
    set_cn_font(r, FONT_HEADING, FONT_ENG, 12, bold=True)

    summary_cn = [
        "当前的转录组比较方法——JS散度、余弦距离、Spearman相关等——仅测量表达差异的幅度。"
        "它们无法区分观察到的差异是反映具有生物学意义的功能性重编程，还是仅仅反映中性转录波动。"
        "这种混合代表了领域内的根本性局限，类似于四十年前Ka/Ks在分子进化中所解决的问题。",

        "我们提出了细胞状态动力学指数（CKI），一种将成对转录组散度分解为中性组分（k_n）"
        "和功能性组分（k_f）的计算框架。CKI omega（ω = k_f/k_n）以持家基因为中性参考进行校准，"
        "提供了一种原则性的选择性转录重编程压力度量。我们在四个互补的尺度上验证了CKI："
        "Tabula Muris（小鼠，15,057个细胞）、Tabula Sapiens（人类，107,399个细胞）、TCGA"
        "（10,535个样本，五种癌症类型）以及Siletti人脑单细胞核图谱"
        "（非神经元细胞，888K细胞核，~100个脑区）。"
        "在脑区分析中，进一步通过乘法模型检测到213个强迁移候选信号（0.67%），"
        "其中OPC延髓迁移走廊（ω = 1.19）得到了血管引导OPC迁移机制的文献验证"
        "（Tsai 2016, Akay 2022）。CKI为从静态转录组数据推断细胞迁移历史"
        "提供了首个定量框架。",
    ]
    for text in summary_cn:
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.5
        r = p.add_run(text)
        set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    # Key advances
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    r = p.add_run("核心创新点")
    set_cn_font(r, FONT_HEADING, FONT_ENG, 12, bold=True)

    advances_cn = [
        ("新的信息维度。",
         "CKI ω与所有四种标准距离度量呈负相关（Spearman r = −0.36至−0.46）。"
         "这并非弱点——而是证明了CKI捕获了现有工具系统性遗漏的正交转录组变异维度。"),
        ("跨物种普适性。",
         "在Tabula Muris、Tabula Sapiens和TCGA三个规模的数据上得到验证，"
         "CKI既复现了预期的生物学层级结构，又揭示了标准方法无法看见的模式。"),
        ("癌症生物学洞见。",
         "在TCGA中，CKI揭示了：(a) 肿瘤转录组矛盾性地比匹配正常组织更均质"
         "（NN/TT比值1.6–3.0倍）；(b) 侵袭性基底样乳腺癌表现出最低的肿瘤内异质性；"
         "(c) 配对肿瘤-正常距离与随机配对无法区分——"
         "这些发现挑战了癌症转录组学中的既有假设。"),
        ("跨器官细胞类型保守性。",
         "CKI ω量化了免疫细胞（巨噬细胞ω = 4.5，CD8+ T = 6.2，中性粒细胞 = 6.1）"
         "的跨器官保守性比结构细胞（红细胞ω = 55.1，内皮细胞 = 35.2）高8–12倍，"
         "首次提供了沿功能轴量化细胞类型保守性的排名。"),
        ("脑区功能分化与迁移推断。",
         "在人脑非神经元细胞图谱（Siletti 2023）的31,764对跨脑区比较中，CKI ω揭示了"
         "7.6倍分化梯度：从Bergmann胶质细胞（ω = 15.97）和血管细胞（ω = 21.54）的"
         "跨脑区高度保守，到星形胶质细胞（ω = 121.77）的极端区域性功能特化。"
         "进一步通过乘法模型检测到213个强迁移候选信号（0.67%），以OPC延髓迁移走廊"
         "（ω = 1.19）为文献验证最充分的案例（Tsai 2016 Science, Akay 2022 Neuron）。"
         "小胶质细胞的迁移信号与主流观点矛盾但可解释为发育定植残留——"
         "提出了可经谱系追踪验证的全新假说。CKI是首个从静态转录组数据"
         "系统推断细胞迁移历史的计算工具。"),
    ]
    for i, (title, body) in enumerate(advances_cn, 1):
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.5
        r = p.add_run(f"{i}. ")
        set_cn_font(r, FONT_HEADING, FONT_ENG, 11, bold=True)
        r = p.add_run(title)
        set_cn_font(r, FONT_HEADING, FONT_ENG, 11, bold=True)
        r = p.add_run(body)
        set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    # Fit
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    r = p.add_run("与Nucleic Acids Research的契合度")
    set_cn_font(r, FONT_HEADING, FONT_ENG, 12, bold=True)

    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.5
    r = p.add_run(
        "CKI是一种广泛适用的计算方法，在单细胞基因组学、癌症生物学、发育生物学和比较转录组学"
        "中具有即时应用价值。该方法的概念清晰性——Ka/Ks类比——使其易于被广泛读者理解，"
        "而其计算简便性（伪批量级别，兼容任何scRNA-seq流程）确保了快速采用。"
        "我们认为这项工作与Nucleic Acids Research强调方法论创新和可验证生物学影响的方向高度一致。"
    )
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    # Related manuscripts
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    r = p.add_run("相关稿件与事先沟通")
    set_cn_font(r, FONT_HEADING, FONT_ENG, 12, bold=True)

    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.5
    r = p.add_run(
        "本稿件未向其他期刊投稿。无相关稿件在审或已接收。"
        "此前未就本工作与Nucleic Acids Research编辑进行沟通。"
    )
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    # Originality
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    r = p.add_run("原创性声明")
    set_cn_font(r, FONT_HEADING, FONT_ENG, 12, bold=True)

    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.5
    r = p.add_run(
        "本稿件呈现的是原创工作，未曾发表，亦未被其他期刊考虑。所有数据来源均为公开可用"
        "（Tabula Muris, Tabula Sapiens, TCGA）。CKI Python软件包"
        "（pip install git+https://github.com/zhanglknt/CKI-cell-type-identification.git）"
        "已在GitHub开源（https://github.com/zhanglknt/CKI-cell-type-identification），"
        "以MIT许可证发布（版本 v1.0.0）。作者声明不存在竞争性经济利益。"
    )
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    doc.add_paragraph()
    doc.add_paragraph()

    # Signature
    p = doc.add_paragraph()
    r = p.add_run("此致")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)
    doc.add_paragraph()

    p = doc.add_paragraph()
    r = p.add_run("Li Zhang (张力)")
    set_cn_font(r, FONT_BODY, FONT_ENG, 12, bold=True)
    doc.add_paragraph()

    sig_lines_cn = [
        "中国医学科学院 北京协和医学院 输血研究所",
        "成都",
        "",
        "北京脑科学与类脑研究所",
        "北京",
        "",
        "电子邮箱：knightz@pumc.edu.cn",
        "",
        "ORCID: 0000-0002-0698-0754",
    ]
    for line in sig_lines_cn:
        if line:
            p = doc.add_paragraph()
            r = p.add_run(line)
            set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    doc.save(OUT["cover"])
    print(f"Saved: {OUT['cover']}")

# ============================================================
# Chinese Supplementary Information
# ============================================================

def build_supplementary_cn():
    doc = Document()
    setup_cn_styles(doc)

    # Title page
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(24)
    r = p.add_run("补充材料")
    set_cn_font(r, FONT_HEADING, FONT_ENG, 16, bold=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("CKI：一种用于量化选择性转录重编程的细胞状态动力学指数")
    set_cn_font(r, FONT_BODY, FONT_ENG, 12, italic=True)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("张力 (Li Zhang)")
    set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    doc.add_page_break()

    # Contents
    add_section_cn(doc, "目录")
    toc_cn = [
        "补充说明1：CKI数学推导（JS散度、k_n、k_f、ω、bootstrap置换检验、伪批量构建）",
        "补充说明2：CKI算法伪代码",
        "补充说明3：统计检验细节",
        "补充说明4：数据集质量控制与过滤标准",
        "补充表1：参数扫描结果（Phase 3.2）",
        "补充表2：跨器官保守性数据（Phase 3.5）",
        "补充表3：人脑非神经元细胞脑区CKI数据",
        "补充表4：脑区间细胞迁移候选数据",
        "补充数据1：全部分析脚本索引",
    ]
    for item in toc_cn:
        p = doc.add_paragraph()
        p.paragraph_format.line_spacing = 1.5
        r = p.add_run(item)
        set_cn_font(r, FONT_BODY, FONT_ENG, 11)

    doc.add_page_break()

    # ================================================================
    # 补充说明1：CKI数学推导
    # ================================================================
    add_section_cn(doc, "补充说明1：CKI数学推导")

    add_section_cn(doc, "1.1 Jensen-Shannon散度", level=2)
    add_body_cn(doc,
        "Jensen-Shannon（JS）散度是Kullback-Leibler散度的对称化平滑版本。"
        "对于两个概率向量p和q：JS(p, q) = 1/2 D(p||m) + 1/2 D(q||m)，"
        "其中m = 1/2(p+q)，D(p||q) = Σ p_i log2(p_i/q_i)。"
        "使用以2为底对数时，JS散度取值[0, 1]。这一界限对于解释omega至关重要："
        "当k_n和k_f均接近1时，omega = k_f/k_n仍可能变化，实践中上限截断为1,000。"
        "CKI计算前先执行softmax归一化，将原始表达向量转换为概率分布："
        "softmax(x)_i = exp(x_i)/Σexp(x_j)。"
    )

    add_section_cn(doc, "1.2 中性偏移速率k_n", level=2)
    add_body_cn(doc,
        "持家（HK）基因定义为在细胞类型和条件下维持稳定表达的基因。"
        "令H = {g1, ..., gM}为HK基因索引集。给定伪批量向量μ_A和μ_B（长度G，总基因数），"
        "中性偏移速率为：k_n = JS(softmax(μ_A[H]), softmax(μ_B[H]))。"
        "原理：HK基因在生物学上相同的细胞群体间不应存在系统性差异。"
        "HK基因上观察到的JS散度因此反映中性噪声：技术变异、随机转录爆发和个体水平生理差异。"
        "k_n由此提供了一个内部中性基线，类似于分子进化中的Ks（同义替换速率）。"
        "HK基因集选择：CKI通过数据驱动自动检测HK基因（联合标准：检出率 > 0.9 且 CV < 30%分位数），辅以HRT Atlas v1.0共识集（1,130个人鼠保守HK基因）为可选增强。"
        "敏感性分析表明CKI结果对HK集选择稳健：使用前10%最低变异基因作为替代中性集合，"
        "omega相关性r > 0.95。"
    )

    add_section_cn(doc, "1.3 功能转化速率k_f", level=2)
    add_body_cn(doc,
        "身份基因I定义为捕获细胞类型特异性功能程序的基因。在默认配置（w1 = 1.0, w2 = 0.0）中，"
        "I由top-N高变基因（HVG）组成，排除HK基因。功能转化速率："
        "k_f = JS(softmax(μ_A[I]), softmax(μ_B[I]))。"
        "扩展配置可纳入额外基因集：（1）regulon活性基因——富集细胞类型特异性转录因子motif的基因；"
        "（2）通路富集基因——两组间差异活跃的MSigDB通路基因；"
        "（3）宏基因嵌入——来自蛋白质语言模型（如ESM-2）的基因水平嵌入。"
        "这些扩展采用加权方式：k_f = w1*JS(HVG) + w2*JS(pathway) + w3*JS(macro)。"
        "参数扫描（Phase 3.2）显示纯身份基因配置（w1=1.0, w2=w3=0.0）实现了最优细胞类型判别"
        "（AUC = 0.786），因此本文采用此作为默认方案。"
    )

    add_section_cn(doc, "1.4 Omega比值及其解释", level=2)
    add_body_cn(doc,
        "ω = k_f/k_n。解释遵循Ka/Ks类比："
        "ω ≈ 1：观察到的转录组差异与中性预期一致，无选择性重编程证据；"
        "ω >> 1：功能差异超过中性偏移，存在选择性转录重编程证据；"
        "ω << 1：功能约束，两组在功能基因上比中性漂变预期更相似（实践中罕见）。"
        "Ka/Ks类比结构上相似但数学上非等同。关键差异："
        "（1）Ka/Ks作用于具有显式密码子模型的序列比对，CKI作用于连续表达向量；"
        "（2）Ka/Ks的中性参考在遗传密码中具有机制基础（同义变化假定为中性），"
        "CKI中的HK基因是经验定义的；（3）Ka/Ks使用显式进化模型（如PAML），"
        "CKI使用经验bootstrap推断。"
    )

    add_section_cn(doc, "1.5 Bootstrap置换检验", level=2)
    add_body_cn(doc,
        "统计推断通过在原假设（两个细胞群体来自同一分布）下生成omega的零分布来进行。流程："
        "（1）为合并数据集中所有细胞标注原始群体标签（A或B）；"
        "（2）随机置换标签B次（默认B=1,000），每次重新计算伪批量向量和omega_null；"
        "（3）经验P值 = (count(ω_null ≥ ω_obs) + 1)/(B + 1)，+1项避免P = 0；"
        "（4）效应量：Cohen's d = (ω_obs − mean(ω_null))/sd(ω_null)。"
        "注：当前分析中未系统施加多重检验校正；所有报告的P值为原始bootstrap P值。"
        "Omega的置信区间通过百分位bootstrap获得：零分布的第2.5和第97.5百分位。"
    )

    add_section_cn(doc, "1.6 伪批量构建", level=2)
    add_body_cn(doc,
        "原始计数矩阵X（细胞×基因）预处理如下："
        "（1）文库大小归一化：X_norm = 10,000 × (X/colSums(X))；"
        "（2）log1p转换：X_log = log1p(X_norm)，稳定方差并降低高表达离群值的影响；"
        "（3）伪批量：μ = 具有相同细胞类型注释的全部细胞的X_log逐列均值，每组至少10个细胞。"
        "对于TCGA bulk RNA-seq数据，改用FPKM归一化：来自GDC的FPKM值，随后进行log2(x+1)转换。"
        "无需伪批量步骤，因为每个样本已是bulk表达谱。"
    )

    doc.add_page_break()

    # ================================================================
    # 补充说明2：CKI算法伪代码
    # ================================================================
    add_section_cn(doc, "补充说明2：CKI算法伪代码")

    add_section_cn(doc, "算法1：CKI核心计算", level=2)
    algo1 = (
        "输入：两个细胞群体A和B（表达矩阵），HK基因集H，身份基因集I（默认top-N HVG \\ H）\n"
        "输出：omega, P值, Cohen's d, 零分布\n\n"
        "1.  X_A, X_B ← 文库归一化并log1p转换A和B\n"
        "2.  μ_A ← mean(X_A, axis=0);  μ_B ← mean(X_B, axis=0)  // 伪批量\n"
        "3.  μ_A_H ← μ_A[H];  μ_B_H ← μ_B[H]\n"
        "4.  k_n ← JS_divergence(softmax(μ_A_H), softmax(μ_B_H))\n"
        "5.  μ_A_I ← μ_A[I];  μ_B_I ← μ_B[I]\n"
        "6.  k_f ← JS_divergence(softmax(μ_A_I), softmax(μ_B_I))\n"
        "7.  omega ← k_f / k_n  // 截断至1,000\n"
        "8.  // Bootstrap\n"
        "9.  labels ← concatenate([A]*n_A, [B]*n_B)\n"
        "10. for b = 1 to B (默认1,000):\n"
        "11.    labels_perm ← random_permutation(labels)\n"
        "12.    A_perm, B_perm ← 按labels_perm拆分\n"
        "13.    omega_null[b] ← CKI_core(A_perm, B_perm, H, I)\n"
        "14. // 推断\n"
        "15. P ← (count(omega_null >= omega) + 1) / (B + 1)\n"
        "16. d ← (omega - mean(omega_null)) / sd(omega_null)"
    )
    add_body_cn(doc, algo1, indent=False)

    add_section_cn(doc, "算法2：逐对身份基因选择（Tabula Sapiens扩展）", level=2)
    algo2 = (
        "不同于Tabula Muris（全局HVG集），Tabula Sapiens采用逐对身份基因选择，"
        "避免HVG在99种细胞类型中被稀释。\n\n"
        "输入：伪批量向量μ_A, μ_B；HK集H；top-N参数N（默认200）\n"
        "1.  Delta ← |μ_A − μ_B|  // 每基因绝对表达差异\n"
        "2.  I ← 按Delta降序排列的top-N基因索引，排除H\n"
        "3.  k_f ← JS(softmax(μ_A[I]), softmax(μ_B[I]))\n\n"
        "注意：k_n使用全局HK集（所有对相同）；k_f使用逐对top-N基因。"
    )
    add_body_cn(doc, algo2, indent=False)

    doc.add_page_break()

    # ================================================================
    # 补充说明3：统计检验细节
    # ================================================================
    add_section_cn(doc, "补充说明3：统计检验细节")

    add_section_cn(doc, "3.1 执行检验与校正策略", level=2)
    add_body_cn(doc,
        "本研究使用以下统计检验：Mann-Whitney U检验（双侧）用于两组间独立比较；"
        "Kruskal-Wallis检验用于多组比较（如BRCA PAM5亚型）；"
        "Jonckheere-Terpstra趋势检验用于有序分类变量（如LIHC Edmondson分级）；"
        "Spearman秩相关用于度量间相关性；Bootstrap置换检验（B=1,000）用于CKI omega显著性推断；"
        "ROC-AUC用于细胞类型分类性能评估。"
    )

    add_section_cn(doc, "3.2 Bootstrap细节", level=2)
    add_body_cn(doc,
        "Bootstrap迭代次数：全部主要结果为B=1,000（Phase 3.2参数扫描使用B=500）。"
        "经验P值公式中分子和分母均使用+1伪计数以避免零P值。"
        "Cohen's d解释：d < 0.2 = 可忽略；0.2–0.5 = 小；0.5–0.8 = 中；> 0.8 = 大。"
        "CKI结果中d值通常>1.0（显著比较），表明大效应量。"
    )

    add_section_cn(doc, "3.3 多重检验校正说明", level=2)
    add_body_cn(doc,
        "注：当前分析中未系统施加Benjamini-Hochberg FDR校正或其他多重检验校正程序。"
        "所有报告的显著性判断均基于原始bootstrap P值（P < 0.05），"
        "效应量（Cohen's d）始终很大（通常d > 1.0），提供额外的证据强度。"
        "TCGA分层分析（BRCA PAM50、LIHC Edmondson）比较数较少（4-5组），"
        "使用综合检验（Kruskal-Wallis、Jonckheere-Terpstra），除综合P值外不附加额外校正。"
    )

    add_section_cn(doc, "3.4 报告惯例", level=2)
    add_body_cn(doc,
        "汇总统计量以均值 ± 标准差（范围）或中位数[四分位距]报告。"
        "箱线图显示：中位数（中心线）、IQR（箱体）、1.5× IQR（须线），超出须线的数据点为离群值。"
        "全文P值均采用双侧检验，除非另有说明。"
        "相关系数（Spearman ρ）附带P值报告。效应量（Cohen's d）随所有显著omega比较报告。"
    )

    doc.add_page_break()

    # ================================================================
    # 补充说明4：数据集质量控制与过滤标准
    # ================================================================
    add_section_cn(doc, "补充说明4：数据集质量控制与过滤标准")

    add_section_cn(doc, "4.1 Tabula Muris FACS（小鼠）", level=2)
    add_body_cn(doc,
        "从GEO（GSE109774）下载。使用FACS分选细胞（非液滴法）以确保较高的单细胞基因检测数。"
        "QC过滤：检测基因<500的细胞移除；线粒体基因表达>10%的细胞移除；"
        "在<3个细胞中检测到的基因移除。结果：15,057个细胞 × 22,308个基因（QC后）。"
        "细胞类型注释：保留每组≥10个细胞的32个细胞类型条目用于伪批量构建，"
        "跨6个器官（肝脏、肾脏、脾脏、肺脏、心脏、骨髓）。"
    )

    add_section_cn(doc, "4.2 Tabula Sapiens（人类）", level=2)
    add_body_cn(doc,
        "从CZ CELLxGENE Discover下载。QC过滤：检测基因<200的细胞移除；"
        "线粒体基因表达>20%的细胞移除。结果：QC后保留108,136个细胞（6个h5ad文件合计），51,852个基因"
        "（从原始58,870过滤后）。细胞类型条目：跨6个器官（Liver、Kidney、Heart、"
        "Bone Marrow、Spleen、Lung）的99个条目。纳入成对omega分析的细胞类型"
        "须在至少一个供体中≥10个细胞。逐对身份基因选择（按|Delta表达|排名top-200基因）"
        "确保每次比较使用对该对最具信息量的基因。人类HK基因：数据驱动自动检测（联合标准），辅以HRT Atlas v1.0中1,129个"
        "具有人类直系同源物、通过gene symbol映射的基因（1个基因无人类直系同源物被排除）。"
    )

    add_section_cn(doc, "4.3 TCGA bulk RNA-seq", level=2)
    add_body_cn(doc,
        "从NCI Genomic Data Commons获取数据。选定五种癌症类型：LUAD（515肿瘤 + 59正常）、"
        "LUSC（501 + 51）、LIHC（371 + 50）、KIRC（533 + 72）、BRCA（1,093 + 113），"
        "总计n = 10,535个样本。归一化：GDC的FPKM值，随后进行log2(x+1)转换。"
        "对于配对分析，按患者barcode（TCGA-XX-XXXX格式）匹配肿瘤-正常对。"
        "分层分析的临床元数据来自GDC（通过TCGAbiolinks R包）和cBioPortal API。"
    )

    add_section_cn(doc, "4.4 高变基因（HVG）选择", level=2)
    add_body_cn(doc,
        "Tabula Muris：使用scanpy.pp.highly_variable_genes进行全局HVG选择，"
        "参数flavor='seurat'、n_top_genes=2,000。全局HVG集用于Phase 3.1–3.2的全部成对比较。"
        "Tabula Sapiens：逐对HVG选择。对于每对细胞类型(CT_i, CT_j)，"
        "按|μ_i − μ_j|（绝对log1p表达差异）排名的top-200基因选为身份基因，排除HK基因。"
        "这避免了跨99种细胞类型比较时HVG的稀释效应。"
        "HVG数量敏感性：参数扫描（Phase 3.2）测试了N_HVG ∈ {50, 100, 200, 500, 1,000, 2,000}。"
        "全局方案（小鼠）在N=2,000时AUC达到最大，但逐对方案（人类）使用N=200"
        "以在保持判别力的同时实现计算效率。"
    )

    doc.add_page_break()

    # ================================================================
    # 补充表
    # ================================================================

    # Table 1
    add_section_cn(doc, "补充表1：参数扫描结果")
    add_body_cn(doc,
        "Phase 3.2在Tabula Muris小鼠数据上的参数扫描（n = 703对细胞类型，6个器官）。"
        "纯身份基因配置（w1 = 1.0, w2 = 0.0）实现了最优细胞类型区分（AUC = 0.786）。"
        "结果见文件 results/phase32_sweep_results.csv，可视化见 "
        "results/phase32_sweep_barplot.png。"
    )

    # Table 2
    add_section_cn(doc, "补充表2：跨器官保守性数据")
    add_body_cn(doc,
        "Tabula Sapiens中59对同一细胞类型跨器官配对的完整数据集，"
        "包括omega、Jensen-Shannon散度、Spearman距离、Cosine距离和Marker Jaccard距离值。"
        "数据见 results/phase35_cross_organ_conservation.csv。"
    )

    # Table 3
    add_section_cn(doc, "补充表3：人脑非神经元细胞脑区CKI数据")
    add_body_cn(doc,
        "Siletti等人（2023）人脑图谱非神经元细胞的CKI脑区分析完整结果，包含10种细胞类型"
        "的31,764对跨脑区比较。每种细胞类型汇总统计量（ω均值、中位数、标准差、范围、"
        "k_n和k_f组分）详见补充表3。原始数据文件：results/brain_region_omega.csv "
        "（31,764行），results/brain_region_summary.csv（10行摘要）。"
        "分析脚本：notebooks/27_brain_region_cki.py。图表生成：notebooks/28_gen_fig6.py。"
        "可视化输出：results/figures_final/figure6_brain_regional_cki.png。"
    )

    doc.add_page_break()

    # Table 4 — Migration
    add_section_cn(doc, "补充表4：脑区间细胞迁移候选数据")
    add_body_cn(doc,
        "基于乘法模型的脑区间潜在细胞迁移候选检测结果。"
        "全量31,764对跨脑区比较中，5,346对（16.83%）被分类为迁移候选："
        "强信号213个（残差 < 0.3, ω < 15, pair内rank=1, pair中位ω > 20），"
        "中等信号1,294个（残差 < 0.5, ω < 25），弱信号3,839个（残差 < 0.75, ω < 35）。"
        "按细胞类型的最强迁移信号（残差排序前5）："
        "OPC MoRF-MoEN vs. MoSR（ω = 1.19, 残差 = 0.033）、"
        "星形胶质细胞 A23 vs. ITG（ω = 2.60, 残差 = 0.041）、"
        "少突胶质细胞 A23 vs. SN（ω = 4.53, 残差 = 0.063）、"
        "OPC GPi vs. PN（ω = 4.14, 残差 = 0.076）、"
        "血管细胞 A44-A45 vs. VA（ω = 1.75, 残差 = 0.083）。"
        "完整候选数据集：results/brain_migration/migration_candidates.csv（5,346行）。"
        "分析脚本：notebooks/29_brain_migration_detection.py。"
        "文献验证报告：results/brain_migration/literature_validation_report.md。"
    )

    doc.add_page_break()

    # ================================================================
    # 补充数据1：脚本索引
    # ================================================================
    add_section_cn(doc, "补充数据1：分析脚本索引")

    scripts_cn = [
        ("Phase 3.1", "01_pilot_mouse.py", "小鼠先导数据集上的初始CKI验证"),
        ("Phase 3.2", "02_ct_pilot.py, 03_full_matrix.py, 04_phase32_sweep.py",
         "小鼠校准、全矩阵、参数扫描"),
        ("Phase 3.3", "05_phase33_human.py (v1–v3)", "人类跨物种验证"),
        ("Phase 3.4", "06_phase34_tcga.py (v1–v2), 08–12 分层分析脚本",
         "TCGA泛癌及分层分析"),
        ("Phase 3.5", "13_phase35_method_comparison.py", "五种度量的方法学比较"),
        ("Phase 3.6", "14_phase36_figures.py, 15_md_to_docx.py, 30_nar_figures_final.py",
         "图表生成与稿件排版"),
        ("脑区分析", "27_brain_region_cki.py", "人脑非神经元细胞跨脑区CKI分析"),
        ("Figure 6", "28_gen_fig6.py", "脑区功能分化图表生成"),
        ("迁移检测", "29_brain_migration_detection.py", "乘法模型脑区间细胞迁移候选检测"),
    ]

    table = doc.add_table(rows=len(scripts_cn)+1, cols=3)
    table.style = "Light Grid Accent 1"
    headers = ["阶段", "脚本", "描述"]
    for j, h in enumerate(headers):
        cell = table.rows[0].cells[j]
        cell.text = h
        for p in cell.paragraphs:
            for r in p.runs:
                set_cn_font(r, FONT_HEADING, FONT_ENG, 9, bold=True)

    for i, (phase, script, desc) in enumerate(scripts_cn):
        for j, val in enumerate([phase, script, desc]):
            cell = table.rows[i+1].cells[j]
            cell.text = val
            for p in cell.paragraphs:
                for r in p.runs:
                    set_cn_font(r, FONT_BODY, FONT_ENG, 9)

    doc.save(OUT["supplementary"])
    print(f"Saved: {OUT['supplementary']}")

# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    build_manuscript_cn()
    build_cover_letter_cn()
    build_supplementary_cn()
    print("\n所有中文DOCX文件生成完毕。")
