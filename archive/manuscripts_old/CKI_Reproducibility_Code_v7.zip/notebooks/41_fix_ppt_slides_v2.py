"""
Fix PPT slides v2:
- Slide 10: Red text (Diff Organ) overlapping red bar → dark text + gap
- Slide 13: "omega = 22.1" overflow beyond card edge → reposition
- Slide 17: Larger migration arrows, remove duplicates from prior run
- All slides: 1.5x paragraph spacing
Covers both EN and ZH versions.
"""

import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pptx import Presentation
from pptx.util import Inches, Emu, Pt
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn
from lxml import etree

BASE = r"C:\Users\KnightZ\Desktop\细胞受选择\results\figures_final"
PPT_EN = os.path.join(BASE, "CKI_Lecture_2026_v3.pptx")
PPT_ZH = os.path.join(BASE, "CKI_Lecture_2026_v3_ZH.pptx")


# ===========================
# Helper: 1.5x paragraph spacing
# ===========================
def set_paragraph_spacing_15(paragraph):
    """Set paragraph line spacing to 150% (1.5x)."""
    pPr = paragraph._p.get_or_add_pPr()
    for old in pPr.findall(qn('a:lnSpc')):
        pPr.remove(old)
    lnSpc = etree.SubElement(pPr, qn('a:lnSpc'))
    spcPct = etree.SubElement(lnSpc, qn('a:spcPct'))
    spcPct.set('val', '150000')


def apply_15_spacing(prs):
    """Apply 1.5x line spacing to all text shapes in all slides."""
    count = 0
    for slide in prs.slides:
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    set_paragraph_spacing_15(para)
                    count += 1
    print(f"  Applied 1.5x spacing to {count} paragraphs")


# ===========================
# Step 1: Generate 4 images for Slide 3
# ===========================
def generate_slide3_images():
    """Generate 4 small scientific illustration PNGs for the 4 method cards."""
    img_dir = os.path.join(BASE, "slide3_images")
    os.makedirs(img_dir, exist_ok=True)
    
    colors = {
        "de": "#2563EB",
        "pw": "#0D9488",
        "pt": "#F59E0B",
        "cl": "#DC2626",
    }
    
    # 1) Differential Expression -> Volcano plot
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    np.random.seed(42)
    n = 200
    fc = np.random.normal(0, 1.5, n)
    pv = -np.log10(np.random.beta(0.5, 5, n) * 0.1 + 0.001)
    colors_pts = ['#94A3B8'] * n
    for i in range(n):
        if abs(fc[i]) > 1.5 and pv[i] > 2: colors_pts[i] = '#DC2626'
        elif abs(fc[i]) > 1.0 and pv[i] > 1.3: colors_pts[i] = '#2563EB'
    ax.scatter(fc, pv, c=colors_pts, s=12, alpha=0.8, edgecolors='none')
    ax.axhline(1.3, color='#D1D5DB', ls='--', lw=0.8)
    ax.axvline(-1, color='#D1D5DB', ls='--', lw=0.8)
    ax.axvline(1, color='#D1D5DB', ls='--', lw=0.8)
    ax.set_xlabel('log2FC', fontsize=7, color='#64748B')
    ax.set_ylabel('-log10(p)', fontsize=7, color='#64748B')
    ax.tick_params(labelsize=6, colors='#94A3B8')
    ax.set_title('Volcano Plot', fontsize=8, color=colors["de"], fontweight='bold')
    fig.tight_layout(pad=0.5)
    de_path = os.path.join(img_dir, "de_volcano.png")
    fig.savefig(de_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    # 2) Pathway Enrichment
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    pathways = ['Ribosome', 'OXPHOS', 'Spliceosome', 'Cell Cycle', 'ECM', 'PI3K-Akt']
    scores = [4.2, 3.8, 2.9, 2.5, 1.8, 1.5]
    ax.barh(pathways[::-1], scores[::-1], height=0.6, color=colors["pw"], alpha=0.85, edgecolor='none')
    ax.set_xlabel('Enrichment', fontsize=7, color='#64748B')
    ax.tick_params(labelsize=6, colors='#64748B')
    ax.set_title('Pathway Enrichment', fontsize=8, color=colors["pw"], fontweight='bold')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    fig.tight_layout(pad=0.5)
    pw_path = os.path.join(img_dir, "pathway_enrich.png")
    fig.savefig(pw_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    # 3) Pseudotime Trajectory
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    np.random.seed(123)
    t = np.linspace(0, 4*np.pi, 80)
    x1 = t + np.random.normal(0, 0.15, 80)
    y1 = np.sin(t) + np.random.normal(0, 0.12, 80)
    x2 = t + np.random.normal(0, 0.15, 80)
    y2 = np.cos(t)*0.5 + 1.5 + np.random.normal(0, 0.12, 80)
    ax.scatter(x1, y1, c=t, cmap='Oranges', s=10, alpha=0.8, edgecolors='none')
    ax.scatter(x2, y2, c=t, cmap='Oranges', s=10, alpha=0.8, edgecolors='none')
    ax.set_title('Pseudotime Trajectory', fontsize=8, color=colors["pt"], fontweight='bold')
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(False)
    fig.tight_layout(pad=0.5)
    pt_path = os.path.join(img_dir, "pseudotime_traj.png")
    fig.savefig(pt_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    # 4) Clustering & Annotation
    fig, ax = plt.subplots(figsize=(2.8, 1.6), dpi=120)
    np.random.seed(99)
    clusters = {
        'A': (np.random.normal(-1, 0.4, 50), np.random.normal(1, 0.4, 50), '#DC2626'),
        'B': (np.random.normal(1.5, 0.35, 50), np.random.normal(0.5, 0.35, 50), '#2563EB'),
        'C': (np.random.normal(-0.8, 0.35, 50), np.random.normal(-1.2, 0.35, 50), '#0D9488'),
        'D': (np.random.normal(2, 0.4, 50), np.random.normal(-0.8, 0.4, 50), '#F59E0B'),
    }
    for name, (cx, cy, clr) in clusters.items():
        ax.scatter(cx, cy, c=clr, s=12, alpha=0.85, edgecolors='none', label=name)
        ax.annotate(name, (np.mean(cx), np.mean(cy)), fontsize=6, ha='center', va='center',
                   color='white', fontweight='bold')
    ax.set_title('Clustering (UMAP)', fontsize=8, color=colors["cl"], fontweight='bold')
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values():
        sp.set_visible(False)
    fig.tight_layout(pad=0.5)
    cl_path = os.path.join(img_dir, "clustering_umap.png")
    fig.savefig(cl_path, dpi=120, bbox_inches='tight', facecolor='#F8FAFC')
    plt.close(fig)
    
    return {"de": de_path, "pw": pw_path, "pt": pt_path, "cl": cl_path}


# ===========================
# Step 2: Fix functions
# ===========================

def fix_slide10(prs):
    """Slide 10: Fix 'Diff Organ' red text overlapping red bar.
    Change text to dark (1E293B), keep red bar as visual indicator."""
    slide = prs.slides[9]
    
    # Fix "Diff Organ" label (shape 27): red DC2626 -> dark 1E293B
    # Also fix "omega ~ 8.1" (shape 31): keep red but ensure no overlap
    for shape in slide.shapes:
        if not shape.has_text_frame:
            continue
        for para in shape.text_frame.paragraphs:
            for run in para.runs:
                if "Diff Organ" in run.text:
                    run.font.color.rgb = RGBColor(0x1E, 0x29, 0x3B)
                    print(f"  Slide 10: 'Diff Organ' → 1E293B (was DC2626)")
                # Also darken "Same Organ" for consistency
                if "Same Organ" in run.text and run.font.color.rgb == RGBColor(0x25, 0x63, 0xEB):
                    run.font.color.rgb = RGBColor(0x1E, 0x29, 0x3B)
                    print(f"  Slide 10: 'Same Organ' → 1E293B")


def fix_slide13(prs):
    """Slide 13: Fix 'omega = 22.1' overflow beyond card boundary.
    Card right edge = 9.45", text was at 8.77+1.20=9.97 → overflows by 0.52".
    Move text to L=8.20, reduce bar width for Basal-like row."""
    slide = prs.slides[12]
    
    target_text = "omega = 22.1"
    for shape in slide.shapes:
        if shape.has_text_frame:
            text = shape.text_frame.text
            if target_text in text:
                # Move text left to fit within card (card edge 9.45, need W=1.2 at L=8.20 = 9.40)
                shape.left = Emu(7510000)  # ~8.21 inches
                print(f"  Slide 13: 'omega = 22.1' moved to L=8.21 (was L=8.77)")
            
            # Also fix the bottom note overflow if "Basal-like > Luminal" is too wide
            if "Basal-like > Luminal" in text:
                # Check and reduce font if needed
                for para in shape.text_frame.paragraphs:
                    for run in para.runs:
                        if run.font.size and run.font.size > Pt(9):
                            run.font.size = Pt(9)
                            print(f"  Slide 13: Bottom note font → 9pt")
    
    # Reduce the red bar width for Basal-like (shape 33)
    # It was W=1.77 (ending at 8.72). Reduce to W=1.50 (ending at 8.45)
    for shape in slide.shapes:
        if hasattr(shape, 'fill'):
            try:
                fill_color = shape.fill.fore_color.rgb
            except:
                continue
            if str(fill_color) == 'DC2626':
                # Check position: Basal-like bar is at L=6.95 T=3.07
                if abs(shape.left - Emu(6360000)) < Emu(200000):
                    shape.width = Emu(1375000)  # ~1.50 inches
                    print(f"  Slide 13: Basal-like red bar width → 1.50in")


def fix_slide17(prs):
    """Slide 17: Remove duplicates from prior run, add larger migration arrows."""
    slide = prs.slides[16]
    
    # --- Step 1: Remove connectors and textboxes added by previous script run ---
    # Connectors have shape_type=9 (MSO_SHAPE.CONNECTOR) or name starts with "Connector"
    # TextBoxes have shape_type=17 or name starts with "TextBox"
    to_remove = []
    for i, shape in enumerate(slide.shapes):
        if shape.name and ("Connector" in shape.name or "TextBox" in shape.name):
            to_remove.append(i)
    
    # Remove in reverse order to preserve indices
    if to_remove:
        # Get the XML element of the slide's shape tree
        spTree = slide.shapes._spTree
        shapes_to_remove = [slide.shapes[i]._element for i in to_remove]
        for elem in shapes_to_remove:
            spTree.remove(elem)
        print(f"  Slide 17: Removed {len(to_remove)} duplicate shapes from prior run")
    
    # --- Step 2: Add new larger arrows ---
    # Brain image position
    img_left = 502920
    img_top = 868680
    img_width = 8138160
    img_height = 2103120
    
    # Arrow 1: SVZ -> Cortex (red)
    svz_x = int(img_left + img_width * 0.35)
    svz_y = int(img_top + img_height * 0.60)
    ctx_x = int(img_left + img_width * 0.65)
    ctx_y = int(img_top + img_height * 0.25)
    
    arrow1 = slide.shapes.add_connector(1, svz_x, svz_y, ctx_x, ctx_y)
    arrow1.line.color.rgb = RGBColor(0xDC, 0x26, 0x26)
    arrow1.line.width = Pt(4.5)  # was 2.5, now bigger
    
    # Larger arrowhead
    ns_a = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    ln1 = arrow1._element.find(qn('a:ln'))
    if ln1 is not None:
        tail_end1 = etree.SubElement(ln1, qn('a:tailEnd'))
        tail_end1.set('type', 'triangle')
        tail_end1.set('w', 'lg')
        tail_end1.set('len', 'lg')
        # Also add headEnd for double arrow appearance
        head_end1 = etree.SubElement(ln1, qn('a:headEnd'))
        head_end1.set('type', 'triangle')
        head_end1.set('w', 'lg')
        head_end1.set('len', 'lg')
    
    # SVZ label
    txBox1 = slide.shapes.add_textbox(
        svz_x - Emu(140000), svz_y + Emu(40000),
        Emu(600000), Emu(240000)
    )
    tf1 = txBox1.text_frame
    p1 = tf1.paragraphs[0]
    run1 = p1.add_run()
    run1.text = "SVZ"
    run1.font.size = Pt(10)
    run1.font.bold = True
    run1.font.color.rgb = RGBColor(0xDC, 0x26, 0x26)
    run1.font.name = "Arial"
    
    # Cortex label
    txBox2 = slide.shapes.add_textbox(
        ctx_x + Emu(80000), ctx_y - Emu(70000),
        Emu(720000), Emu(240000)
    )
    tf2 = txBox2.text_frame
    p2 = tf2.paragraphs[0]
    run2 = p2.add_run()
    run2.text = "Cortex"
    run2.font.size = Pt(10)
    run2.font.bold = True
    run2.font.color.rgb = RGBColor(0xDC, 0x26, 0x26)
    run2.font.name = "Arial"
    
    # Arrow 2: OPC -> Cortex (blue)
    opc_x = int(img_left + img_width * 0.30)
    opc_y = int(img_top + img_height * 0.55)
    ctx2_x = int(img_left + img_width * 0.75)
    ctx2_y = int(img_top + img_height * 0.15)
    
    arrow2 = slide.shapes.add_connector(1, opc_x, opc_y, ctx2_x, ctx2_y)
    arrow2.line.color.rgb = RGBColor(0x25, 0x63, 0xEB)
    arrow2.line.width = Pt(4.0)  # was 2.5, now bigger
    
    ln2 = arrow2._element.find(qn('a:ln'))
    if ln2 is not None:
        tail_end2 = etree.SubElement(ln2, qn('a:tailEnd'))
        tail_end2.set('type', 'triangle')
        tail_end2.set('w', 'lg')
        tail_end2.set('len', 'lg')
    
    # OPC label
    txBox3 = slide.shapes.add_textbox(
        opc_x - Emu(180000), opc_y + Emu(40000),
        Emu(600000), Emu(240000)
    )
    tf3 = txBox3.text_frame
    p3 = tf3.paragraphs[0]
    run3 = p3.add_run()
    run3.text = "OPC"
    run3.font.size = Pt(10)
    run3.font.bold = True
    run3.font.color.rgb = RGBColor(0x25, 0x63, 0xEB)
    run3.font.name = "Arial"
    
    print(f"  Slide 17: Added larger migration arrows (Pt 4.0-4.5)")


def add_image_to_slide3(prs, card_img_map):
    """Slide 3: Add 4 illustration images to the 4 method cards."""
    slide = prs.slides[2]
    
    cards = [
        {"name": "de", "left": 502920, "top": 960120, "width": 1931670, "height": 2743200},
        {"name": "pw", "left": 2571750, "top": 960120, "width": 1931670, "height": 2743200},
        {"name": "pt", "left": 4640580, "top": 960120, "width": 1931670, "height": 2743200},
        {"name": "cl", "left": 6709410, "top": 960120, "width": 1931670, "height": 2743200},
    ]
    
    for card in cards:
        img_path = card_img_map.get(card["name"])
        if not img_path or not os.path.exists(img_path):
            print(f"  Slide 3: Image not found for {card['name']}, skipping")
            continue
        
        margin = 120000
        img_left = card["left"] + margin
        img_top = card["top"] + 2100000
        img_width = card["width"] - 2 * margin
        img_height = 500000
        
        try:
            slide.shapes.add_picture(img_path, img_left, img_top, img_width, img_height)
            print(f"  Slide 3: Added {card['name']} image")
        except Exception as e:
            print(f"  Slide 3: Failed to add {card['name']}: {e}")


# ===========================
# Main
# ===========================
print("Generating 4 illustration images...")
image_paths = generate_slide3_images()
print(f"  Generated: {list(image_paths.values())}")

for ppt_name, ppt_path in [("EN", PPT_EN), ("ZH", PPT_ZH)]:
    print(f"\n{'='*50}")
    print(f"Processing {ppt_name} PPT: {os.path.basename(ppt_path)}")
    print(f"{'='*50}")
    
    prs = Presentation(ppt_path)
    
    # Check if slide count is enough
    if len(prs.slides) < 17:
        print(f"  ERROR: Only {len(prs.slides)} slides, need 17+")
        continue
    
    # Fix slide 10
    fix_slide10(prs)
    
    # Fix slide 13
    fix_slide13(prs)
    
    # Fix slide 17 (includes duplicate cleanup)
    fix_slide17(prs)
    
    # Add images to slide 3
    add_image_to_slide3(prs, image_paths)
    
    # Apply 1.5x paragraph spacing (MUST be last to cover new shapes too)
    apply_15_spacing(prs)
    
    # Save
    prs.save(ppt_path)
    print(f"  Saved: {ppt_path}")

print("\nDone! All PPT fixes applied (v2).")
