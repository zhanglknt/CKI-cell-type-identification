"""
Fix PPT slides to reflect universal gene selection principles.
Replaces HRT Atlas-dependent language with data-driven descriptions.
Covers both EN and ZH PPTs.
"""

from pptx import Presentation
from pptx.util import Pt
from pptx.dml.color import RGBColor
import os
import copy

BASE = r"C:\Users\KnightZ\Desktop\细胞受选择\results\figures_final"

# Text replacement map: (old_text_substring, new_text, slide_num)
EN_REPLACEMENTS = {
    6: [
        # Slide 6: Step 1 description
        (
            "1,064 conserved human-mouse housekeeping genes from HRT Atlas v1.0. Constitutively expressed across tissues.",
            "Auto-detected per dataset: detection rate >90% AND CV <30th percentile. No external reference required for any species."
        ),
        # Slide 6: Step 2 description
        (
            "Top 500 most variable genes per cell-type pair, ranked by expression variance. Captures cell-type-specific programs.",
            "Top 2,000 highly variable genes (HVGs; Seurat v3), excluding HK genes. Captures cell-type-specific programs."
        ),
    ],
    8: [
        # Slide 8: HK genes sub-text
        (
            "HRT Atlas v1.0, human-mouse conserved",
            "Auto-detected: detection rate + CV filter"
        ),
        # Slide 8: Identity genes sub-text
        (
            "Top variable genes ranked by variance",
            "Top 2,000 HVGs (Seurat v3), excluding HK genes"
        ),
    ],
    18: [
        # Slide 18: Summary bullet
        (
            "Housekeeping genes serve as an internal calibration standard, analogous to synonymous mutations in molecular evolution. 1,064 conserved human-mouse HK genes.",
            "Housekeeping genes serve as an internal calibration standard, analogous to synonymous mutations in molecular evolution. Auto-detected per dataset (detection rate + CV) — works for any species."
        ),
    ],
}

ZH_REPLACEMENTS = {
    6: [
        # Slide 6: Step 1 - HK gene selection
        (
            "从 HRT Atlas v1.0选取 1,064个保守的人-鼠持家基因，跨组织稳定表达。",
            "基于数据自动检测：检出率 >90% 且 CV < 30%分位数。适用于任意物种，无需外部参考集。"
        ),
        # Slide 6: Step 2 - identity gene set
        (
            "每对细胞类型选取表达变异最大的前500基因，捕获细胞特异性程序。",
            "Top 2,000高变基因（HVG；Seurat v3），排除持家基因。捕获细胞特异性程序。"
        ),
    ],
    8: [
        (
            "HRT Atlas v1.0，人-鼠保守",
            "数据驱动检测：检出率 + CV过滤"
        ),
        (
            "按表达变异排序的前500基因",
            "Top 2,000 HVG（Seurat v3），排除HK基因"
        ),
    ],
    18: [
        (
            "基于1,064个保守的人-鼠持家基因。",
            "数据驱动HK基因检测（检出率 + CV），任意物种适用。"
        ),
    ],
}

def fix_runs_in_shape(shape, old_text, new_text):
    """Replace text in shape's runs. Returns True if any change was made."""
    changed = False
    if not shape.has_text_frame:
        return changed
    
    full_text = shape.text_frame.text
    if old_text not in full_text:
        return changed
    
    # Approach: rebuild all runs
    for paragraph in shape.text_frame.paragraphs:
        for run in paragraph.runs:
            if old_text in run.text:
                run.text = run.text.replace(old_text, new_text)
                changed = True
    
    return changed


def fix_ppt(ppt_path, replacements, lang_label):
    """Apply text replacements to a PPT file."""
    if not os.path.exists(ppt_path):
        print(f"  SKIP: {ppt_path} not found")
        return 0
    
    prs = Presentation(ppt_path)
    total_changes = 0
    
    for slide_num, rep_list in replacements.items():
        slide = prs.slides[slide_num - 1]  # 0-indexed
        for old_text, new_text in rep_list:
            for shape in slide.shapes:
                if fix_runs_in_shape(shape, old_text, new_text):
                    total_changes += 1
                    print(f"  [{lang_label}] Slide {slide_num}: replaced text")
    
    if total_changes > 0:
        prs.save(ppt_path)
        print(f"  [{lang_label}] Saved with {total_changes} changes")
    else:
        print(f"  [{lang_label}] No changes made")
    
    return total_changes


if __name__ == "__main__":
    total = 0
    
    # EN PPT
    en_path = os.path.join(BASE, "CKI_Lecture_2026_v3.pptx")
    print(f"\n=== EN PPT: {en_path} ===")
    total += fix_ppt(en_path, EN_REPLACEMENTS, "EN")
    
    # ZH PPT
    zh_path = os.path.join(BASE, "CKI_Lecture_2026_v3_ZH.pptx")
    print(f"\n=== ZH PPT: {zh_path} ===")
    
    total += fix_ppt(zh_path, ZH_REPLACEMENTS, "ZH")
    
    print(f"\nTotal changes: {total}")
