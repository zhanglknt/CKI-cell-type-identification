"""
Fix Slide 10 right card (Cross-Organ Discrimination) + Slide 13 right card overflow.
"""

from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor

# ═══════════════════════════════════════════
# SLIDE 10 RIGHT CARD FIXES
# ═══════════════════════════════════════════

def fix_slide10_right(prs, lang):
    s = prs.slides[9]

    # Color palette
    ACCENT_GREEN = RGBColor(0x0D, 0x94, 0x88)
    DARK = RGBColor(0x1E, 0x29, 0x3B)
    SUBTLE = RGBColor(0x64, 0x74, 0x8B)
    BLUE = RGBColor(0x25, 0x63, 0xEB)
    RED = RGBColor(0xDC, 0x26, 0x26)
    WHITE = RGBColor(0xFF, 0xFF, 0xFF)

    # Title [21]: change color to match accent bar
    title = s.shapes[21]
    for r in title.text_frame.paragraphs[0].runs:
        r.font.color.rgb = ACCENT_GREEN

    # Subtitle [22]: keep 9pt gray, fine

    # Note text [25]: 8pt → 9pt
    note = s.shapes[25]
    for p in note.text_frame.paragraphs:
        for r in p.runs:
            r.font.size = Pt(9)

    # "Same Organ" label [26]: color → blue
    label_same = s.shapes[26]
    for r in label_same.text_frame.paragraphs[0].runs:
        r.font.color.rgb = BLUE

    # "Diff Organ" label [27]: color → red
    label_diff = s.shapes[27]
    for r in label_diff.text_frame.paragraphs[0].runs:
        r.font.color.rgb = RED

    # Match bar heights: blue bar [28] H=320040, red bar [29] H=502920 → unify to 365760
    bar_blue = s.shapes[28]
    bar_red = s.shapes[29]
    bar_blue.height = 365760
    bar_red.height = 365760
    bar_red.top = bar_blue.top  # align tops

    # Omega text [30], [31]: 8pt → 9pt, already white, good
    for idx in [30, 31]:
        omega = s.shapes[idx]
        # Move omega text to bar bottom edge
        parent_bar = s.shapes[28] if idx == 30 else s.shapes[29]
        omega.top = parent_bar.top + parent_bar.height + 45720
        for r in omega.text_frame.paragraphs[0].runs:
            r.font.size = Pt(9)

    # Fix bar vertical alignment:
    # Move bars up to be closer to labels
    bar_blue.top = 2377440
    bar_red.top = 2377440
    # Omega text below bars
    s.shapes[30].top = 2377440 + 365760 + 45720  # 2788920
    s.shapes[31].top = 2377440 + 365760 + 45720  # 2788920

    print(f"  [{lang}] Slide 10 right card: ✓")


# ═══════════════════════════════════════════
# SLIDE 13 RIGHT CARD OVERFLOW FIX
# ═══════════════════════════════════════════

def fix_slide13_overflow(prs, lang):
    s = prs.slides[12]

    # Constants
    BAR_X = 6355080
    CARD_RIGHT = 8641080
    OMEGA_TEXT_WIDTH = 822960  # ~0.9"
    RIGHT_MARGIN = 45720

    OMEGA_RIGHT = CARD_RIGHT - RIGHT_MARGIN
    OMEGA_LEFT = OMEGA_RIGHT - OMEGA_TEXT_WIDTH
    BAR_END = OMEGA_LEFT - 45720
    MAX_BAR = BAR_END - BAR_X

    # Subtype data (matches shape order 23,26,29,32,35)
    subtypes = [
        ("Luminal A",     8.2),
        ("Luminal B",    10.5),
        ("HER2-enriched", 15.3),
        ("Basal-like",   22.1),
        ("Normal-like",   6.8),
    ]
    subtypes_zh = [
        ("Luminal A",     8.2),
        ("Luminal B",    10.5),
        ("HER2富集型",  15.3),
        ("基底样",       22.1),
        ("正常样",        6.8),
    ]

    data = subtypes_zh if 'ZH' in lang else subtypes
    bar_indices = [24, 27, 30, 33, 36]
    omega_indices = [25, 28, 31, 34, 37]

    for i, (label, omega_val) in enumerate(data):
        bar_w = int(omega_val / 22.1 * MAX_BAR)
        bar_s = s.shapes[bar_indices[i]]
        omega_s = s.shapes[omega_indices[i]]

        # Resize bar to fit within card
        bar_s.width = bar_w

        # Position omega text at fixed right-aligned position
        omega_s.left = OMEGA_LEFT
        omega_s.width = OMEGA_TEXT_WIDTH

    print(f"  [{lang}] Slide 13 overflow: ✓ (max bar={MAX_BAR} EMU)")


# ═══════════════════════════════════════════
# APPLY
# ═══════════════════════════════════════════

for lang, path in [
    ("EN", r"results/figures_final/CKI_Lecture_2026_v3.pptx"),
    ("ZH", r"results/figures_final/CKI_Lecture_2026_v3_ZH.pptx"),
]:
    print(f"Fixing {path}...")
    prs = Presentation(path)
    fix_slide10_right(prs, lang)
    fix_slide13_overflow(prs, lang)
    prs.save(path)

print("\nDone!")
