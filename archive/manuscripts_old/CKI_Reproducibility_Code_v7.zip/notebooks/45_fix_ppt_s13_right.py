"""
Fix Slide 13 right card (BRCA PAM50) — color scheme and text layout.
Issues:
  1. Font sizes: 9pt (vs 10pt on left), Basal-like at 8pt → unify to 10pt
  2. Colors: rainbow gradient misapplied to subtypes without natural ordering
     → Use blue gradient (light→dark proportional to omega)
  3. Row spacing uneven → uniform 400k EMU spacing
  4. Bottom summary 8pt → 9pt, better positioning
  5. Basal-like bar/text position overlaps → fix all Y positions
"""

from pptx import Presentation
from pptx.util import Emu, Pt
from pptx.dml.color import RGBColor
from copy import deepcopy

# ── Color constants ──
CARD_BG = RGBColor(0xFF, 0xFF, 0xFF)        # FFFFFF
ACCENT_BAR_BLUE = RGBColor(0x25, 0x63, 0xEB)  # 2563EB
LABEL_DARK = RGBColor(0x1E, 0x29, 0x3B)       # 1E293B
SUMMARY_BG = RGBColor(0xEF, 0xF6, 0xFF)       # EFF6FF

# Blue gradient for bars (light→dark = low→high omega)
BAR_COLORS = {
    "Normal-like":   RGBColor(0x93, 0xC5, 0xFD),  # blue-300  (omega 6.8)
    "Luminal A":     RGBColor(0x60, 0xA5, 0xFA),  # blue-400  (omega 8.2)
    "Luminal B":     RGBColor(0x3B, 0x82, 0xF6),  # blue-500  (omega 10.5)
    "HER2-enriched": RGBColor(0x25, 0x63, 0xEB),  # blue-600  (omega 15.3)
    "Basal-like":    RGBColor(0x1D, 0x4E, 0xD8),  # blue-700  (omega 22.1)
}

# ZH labels
BAR_COLORS_ZH = {
    "正常样":       RGBColor(0x93, 0xC5, 0xFD),
    "Luminal A":    RGBColor(0x60, 0xA5, 0xFA),
    "Luminal B":    RGBColor(0x3B, 0x82, 0xF6),
    "HER2富集型":   RGBColor(0x25, 0x63, 0xEB),
    "基底样":       RGBColor(0x1D, 0x4E, 0xD8),
}

# ── Layout constants (EMU) ──
CARD_LEFT = 4617720
CARD_TOP = 960120
CARD_WIDTH = 4023360
CARD_HEIGHT = 2926080

LABEL_X = 4800600
BAR_X = 6355080
BAR_HEIGHT = 164592  # ~17px, slightly taller

# Omega scaling: bar width proportional to omega value
MAX_OMEGA = 22.1
MAX_BAR_WIDTH = CARD_LEFT + CARD_WIDTH - BAR_X - 274320  # leave margin for text

ROW_DATA = [
    # (label, omega, row_y) — order matches PPT shape indices 23,26,29,32,35
    ("Luminal A",     8.2,  1463040),
    ("Luminal B",    10.5,  1863040),
    ("HER2-enriched", 15.3, 2263040),
    ("Basal-like",   22.1,  2663040),
    ("Normal-like",   6.8,  3063040),
]

ROW_DATA_ZH = [
    ("Luminal A",     8.2,  1463040),
    ("Luminal B",    10.5,  1863040),
    ("HER2富集型",  15.3,  2263040),
    ("基底样",       22.1,  2663040),
    ("正常样",        6.8,  3063040),
]

SUMMARY_Y = 3460000
SUMMARY_H = 320000


def bar_width_for_omega(omega):
    return int(omega / MAX_OMEGA * MAX_BAR_WIDTH)


def fix_right_card(prs, row_data, bar_colors, summary_text, base_bar_color):
    """Fix all right-card elements on Slide 13."""
    s = prs.slides[12]

    # We'll operate by index since names may not be reliable across versions
    # The right card elements are indices 20-39
    # Shape 20: white card background
    # Shape 21: accent bar
    # Shape 22: card title
    # Shapes 23-37: subtype labels, bars, omega values (alternating)
    # Shape 38: summary background
    # Shape 39: summary text

    # ── 1. Fix subtype bars (shapes 24,27,30,33,36) and labels (23,25,26,28,29,31,32,34,35,37) ──
    # EN order: label,bar,omega repeated 5 times (5 subtypes)
    # [23] Luminal A label, [24] bar, [25] omega
    # [26] Luminal B label, [27] bar, [28] omega
    # [29] HER2 label, [30] bar, [31] omega
    # [32] Basal-like label, [33] bar, [34] omega
    # [35] Normal-like label, [36] bar, [37] omega

    label_indices = [23, 26, 29, 32, 35]
    bar_indices = [24, 27, 30, 33, 36]
    omega_indices = [25, 28, 31, 34, 37]

    for i, (label_text, omega, row_y) in enumerate(row_data):
        bar_w = bar_width_for_omega(omega)
        bar_y = row_y + 27432  # small offset below label

        # ── Label ──
        label_s = s.shapes[label_indices[i]]
        label_s.top = row_y
        label_s.height = BAR_HEIGHT + 36576
        for para in label_s.text_frame.paragraphs:
            for run in para.runs:
                run.font.size = Pt(10)
                run.font.color.rgb = LABEL_DARK

        # ── Bar ──
        bar_s = s.shapes[bar_indices[i]]
        bar_s.left = BAR_X
        bar_s.top = bar_y
        bar_s.width = bar_w
        bar_s.height = BAR_HEIGHT
        bar_s.fill.solid()
        bar_color = bar_colors.get(label_text, base_bar_color)
        bar_s.fill.fore_color.rgb = bar_color

        # ── Omega value ──
        omega_s = s.shapes[omega_indices[i]]
        omega_text_x = BAR_X + bar_w + 91440  # ~0.1" margin after bar
        omega_s.left = omega_text_x
        omega_s.top = row_y
        omega_s.height = BAR_HEIGHT + 36576
        for para in omega_s.text_frame.paragraphs:
            for run in para.runs:
                run.font.size = Pt(10)
                run.font.color.rgb = bar_color

    # ── 2. Fix card accent bar and title ──
    # Shape 21: accent bar — already blue, just ensure consistent
    accent = s.shapes[21]
    accent.fill.solid()
    accent.fill.fore_color.rgb = ACCENT_BAR_BLUE

    # Shape 22: card title — already 13pt blue, keep

    # ── 3. Fix summary background and text ──
    # Shape 38: summary bg
    summary_bg = s.shapes[38]
    summary_bg.top = SUMMARY_Y
    summary_bg.height = SUMMARY_H
    summary_bg.fill.solid()
    summary_bg.fill.fore_color.rgb = SUMMARY_BG

    # Shape 39: summary text
    summary_text_s = s.shapes[39]
    summary_text_s.top = SUMMARY_Y + 36576
    summary_text_s.height = SUMMARY_H - 73152
    for para in summary_text_s.text_frame.paragraphs:
        for run in para.runs:
            run.font.size = Pt(9)
            run.font.color.rgb = ACCENT_BAR_BLUE


# ── Apply to both EN and ZH ──
for lang, path, row_data, bar_colors, summary_text, base_color in [
    ("EN", r"results/figures_final/CKI_Lecture_2026_v3.pptx",
     ROW_DATA, BAR_COLORS, "Basal-like > Luminal: more aggressive = higher omega",
     RGBColor(0x25, 0x63, 0xEB)),
    ("ZH", r"results/figures_final/CKI_Lecture_2026_v3_ZH.pptx",
     ROW_DATA_ZH, BAR_COLORS_ZH, "基底样 > Luminal：更侵袭性 = 更高 omega",
     RGBColor(0x25, 0x63, 0xEB)),
]:
    print(f"Fixing {lang} PPT...")
    prs = Presentation(path)
    fix_right_card(prs, row_data, bar_colors, summary_text, base_color)
    prs.save(path)
    print(f"  ✓ Saved {path}")

print("\nDone! Slide 13 right card fixed.")
